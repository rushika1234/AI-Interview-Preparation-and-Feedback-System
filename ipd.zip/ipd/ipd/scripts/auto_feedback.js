(async () => {
  try {
    const base = 'http://localhost:3000';
    const qRes = await fetch(base + '/questions/random/8');
    const qData = await qRes.json();
    const qs = qData.questions || qData;

    const responses = qs.map(q => {
      if (q.type === 'mcq') {
        const pick = Math.random() < 0.5 ? q.correctAnswer : q.options.find(o => o !== q.correctAnswer);
        return { questionId: q.id, answer: pick };
      } else {
        const keywords = q.expectedKeywords || [];
        const pick = keywords.slice(0, Math.min(2, keywords.length)).join(' ');
        return { questionId: q.id, answer: pick ? ('Includes ' + pick) : 'Sample answer' };
      }
    });

    const body = { username: 'automation', responses };
    const fbRes = await fetch(base + '/feedback', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const fb = await fbRes.json();
    console.log(JSON.stringify(fb, null, 2));
  } catch (err) {
    console.error('Error:', err);
    process.exit(1);
  }
})();
