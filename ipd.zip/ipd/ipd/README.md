# AI Interview Preparation and Feedback System

A comprehensive interview preparation platform with AI-powered feedback analysis, featuring 60+ questions across multiple categories with MCQ and normal Q&A formats.

## Features

✅ **Comprehensive Question Bank** - 60+ questions across 4 categories:
   - Data Structures (20+ questions)
   - Algorithms (20+ questions)
   - Database Management Systems (20+ questions)
   - Python (3+ questions)

✅ **Mixed Question Formats**:
   - MCQ (Multiple Choice Questions) - with instant feedback
   - Normal Q&A - with keyword-based evaluation

✅ **Mock Interview System**:
   - Customizable number of questions (1-20)
   - Random question selection
   - Real-time interview conductor

✅ **Advanced Feedback Analysis**:
   - Overall performance score
   - Performance level classification
   - Category-wise breakdown
   - Strengths and weaknesses identification
   - Personalized recommendations

✅ **User-Friendly Interface**:
   - Login system
   - Question browser by category
   - Interactive dashboard with 4 tabs

## Technology Stack

- **Backend**: Node.js with Express.js
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Storage**: In-memory storage (no database required)
- **API**: RESTful API with CORS enabled

## Project Structure

```
ipd/
├── backend/
│   ├── server.js                 # Main Express server
│   ├── comprehensiveQuestions.js # 60+ question database
│   ├── database.js               # MongoDB schema (optional)
│   └── package.json              # Node dependencies
├── dashboard.html                # Main dashboard interface
├── index.html                    # Login redirector
├── login.html                    # Legacy login page
└── README.md                     # This file
```

## Installation & Setup

### Prerequisites
- Node.js (v12 or higher)
- npm (comes with Node.js)

### Step 1: Install Dependencies

```bash
cd "c:\Users\Goparapu Sathvika\Desktop\sem-2\ipd\backend"
npm install
```

Required packages:
- `express` - Web framework
- `cors` - Cross-Origin Resource Sharing

### Step 2: Start the Backend Server

```bash
cd "c:\Users\Goparapu Sathvika\Desktop\sem-2\ipd\backend"
node server.js
```

You should see:
```
Questions loaded: 63
========== SERVER STARTED ==========
Server is running on http://localhost:3000
```

### Step 3: Open the Application

Open your browser and navigate to:
```
file:///c:/Users/Goparapu%20Sathvika/Desktop/sem-2/ipd/dashboard.html
```

Or simply open `dashboard.html` from the file explorer.

## API Endpoints

### 1. Get All Questions
```
GET http://localhost:3000/questions/all
```
Returns: Array of all questions with metadata

### 2. Get Questions by Category
```
GET http://localhost:3000/questions/category/:categoryName
```
Example: `/questions/category/Data Structures`

### 3. Get Questions by Difficulty
```
GET http://localhost:3000/questions/difficulty/:level
```
Levels: `beginner`, `intermediate`, `advanced`

### 4. Get Random Questions
```
GET http://localhost:3000/questions/random/:count
```
Example: `/questions/random/5` returns 5 random questions

### 5. Get All Categories
```
GET http://localhost:3000/categories
```
Returns: List of all available categories

### 6. Submit Interview and Get Feedback
```
POST http://localhost:3000/feedback
Content-Type: application/json

{
  "username": "user123",
  "responses": [
    {
      "questionId": 1,
      "answer": "user's answer",
      "type": "mcq|normal"
    }
  ]
}
```

Response includes:
- Overall score (0-100)
- Performance level (Excellent/Good/Fair/Average/Needs Improvement)
- Category-wise analysis
- Strengths and weaknesses
- Personalized recommendations
- Detailed feedback per question

## Using the Application

### 1. Login
- Enter any username and password (authentication is minimal)
- Click "Login"

### 2. Home Tab
- View statistics (total questions, categories)
- See category cards with question counts
- Click any category to start browsing

### 3. Questions Tab
- Select a category from dropdown
- Browse all questions with difficulty levels
- View both MCQ and normal Q&A formats

### 4. Mock Interview Tab
- Set number of questions (1-20)
- Click "Start Interview"
- Answer questions as they appear
- Use "Next Question" or "Skip" buttons
- Submit when complete

### 5. Results Tab
- View overall score
- See performance level classification
- Review category-wise performance
- Read identified strengths and weaknesses
- Get personalized recommendations
- Review detailed feedback per question

## Question Database Structure

Each question has the following structure:

### MCQ Format:
```javascript
{
  id: 1,
  type: 'mcq',
  category: 'Data Structures',
  difficulty: 'beginner',
  question: 'What is a data structure?',
  options: ['Option A', 'Option B', 'Option C', 'Option D'],
  correctAnswer: 'Option A',
  explanation: 'Explanation of the answer...'
}
```

### Normal Q&A Format:
```javascript
{
  id: 11,
  type: 'normal',
  category: 'Data Structures',
  difficulty: 'beginner',
  question: 'Explain the difference between an array and a linked list.',
  expectedKeywords: ['array', 'linked list', 'memory', ...],
  explanation: 'Detailed explanation...'
}
```

## Feedback System Details

The feedback analysis includes:

### Summary
- Total questions attempted
- Overall score percentage
- Performance level

### Category-wise Analysis
- Breakdown by category
- Percentage score for each category

### Overall Analysis
- **Strengths**: Areas where user performed well
- **Weaknesses**: Areas needing improvement

### Recommendations
- Personalized suggestions based on performance
- Resources and topics to focus on

### Detailed Feedback
- Per-question analysis
- Correct answers and explanations
- Why responses were marked correct/incorrect

## Performance Levels

- **Excellent** (90-100%) - Outstanding knowledge
- **Good** (70-89%) - Strong understanding
- **Fair** (50-69%) - Adequate knowledge
- **Average** (30-49%) - Basic understanding
- **Needs Improvement** (0-29%) - Requires significant study

## Troubleshooting

### Server won't start
- Check if port 3000 is already in use
- Ensure Node.js is installed: `node --version`
- Navigate to correct backend directory

### Questions not loading
- Verify server is running (`node server.js` output shows "Questions loaded: 63")
- Check browser console for CORS errors
- Ensure `comprehensiveQuestions.js` exists in backend folder

### Dashboard not displaying
- Open browser console (F12) to check for errors
- Verify server URL is correct (`http://localhost:3000`)
- Try opening in a different browser

### Feedback not showing
- Submit interview completely (all questions)
- Check that responses were properly sent
- Verify backend console for any errors

## Expanding the Question Bank

To add more questions, edit `comprehensiveQuestions.js`:

1. Open `/backend/comprehensiveQuestions.js`
2. Add new questions following the structure above
3. Increment the `id` field for each new question
4. Save and restart the server
5. New questions will be automatically loaded

## Future Enhancements

- Database integration (MongoDB/PostgreSQL)
- Advanced analytics dashboard
- Interview history tracking
- Performance trends analysis
- Audio/video interview simulation
- AI-powered response evaluation using NLP
- Difficulty-based adaptive questioning
- Category-wise study plans

## Notes

- The system uses in-memory storage, so data is not persisted between server restarts
- No database setup required - all questions are loaded from `comprehensiveQuestions.js`
- CORS is enabled for all origins to allow frontend-backend communication
- Questions are randomly selected for mock interviews

## Support

For issues or feature requests, check:
1. Backend console output
2. Browser developer console (F12)
3. Verify all files are in correct locations
4. Ensure port 3000 is available

---

**Version**: 1.0
**Last Updated**: 2024
**Status**: Fully Functional
