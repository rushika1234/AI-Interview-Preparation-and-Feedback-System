# Quick Start Guide - AI Interview Preparation System

## 3-Minute Setup

### Step 1: Install Dependencies (2 minutes)
Open PowerShell in the backend folder:
```powershell
cd "c:\Users\Goparapu Sathvika\Desktop\sem-2\ipd\backend"
npm install
```

### Step 2: Start the Server (30 seconds)
```powershell
node server.js
```

You should see:
```
Questions loaded: 63
========== SERVER STARTED ==========
Server is running on http://localhost:3000
```

### Step 3: Open the Application (30 seconds)
Open `dashboard.html` from:
```
c:\Users\Goparapu Sathvika\Desktop\sem-2\ipd\dashboard.html
```

Or paste this in your browser:
```
file:///c:/Users/Goparapu%20Sathvika/Desktop/sem-2/ipd/dashboard.html
```

## Login Credentials
- Username: Any text (e.g., "student1")
- Password: Any text (e.g., "password123")

## What You Get

✅ **60+ Interview Questions**
- Data Structures: 20 questions
- Algorithms: 20 questions  
- DBMS: 20 questions
- Python: 3 bonus questions

✅ **Mixed Formats**
- MCQs (Multiple Choice) with instant feedback
- Normal Q&A with keyword-based scoring

✅ **Comprehensive Feedback**
- Overall score and performance level
- Category-wise breakdown
- Strengths and weaknesses analysis
- Personalized recommendations

## Usage

1. **Login** with any username/password
2. **Home Tab**: See statistics and browse categories
3. **Questions Tab**: Study questions by category
4. **Mock Interview**: Practice with random questions
5. **Results Tab**: Get detailed analysis

## Features at a Glance

| Feature | Details |
|---------|---------|
| Total Questions | 63 (Mix of MCQ and Normal) |
| Categories | 4 (Data Structures, Algorithms, DBMS, Python) |
| Interview Types | Random selection, custom count (1-20) |
| Feedback | Overall score, category breakdown, recommendations |
| Storage | In-memory (no database needed) |
| Setup Time | ~2 minutes |

## Common Issues & Solutions

| Issue | Solution |
|-------|----------|
| "Cannot find module" | Run `npm install` in backend folder |
| Port 3000 already in use | Stop other Node processes or change port in server.js |
| Dashboard won't load | Ensure server is running and showing "Questions loaded: 63" |
| Questions blank | Restart server: Ctrl+C then `node server.js` |

## Directory Structure
```
ipd/
├── backend/
│   ├── server.js (Main server)
│   ├── comprehensiveQuestions.js (All questions)
│   ├── package.json (Dependencies)
│   └── package-lock.json
├── dashboard.html (Open this file!)
├── index.html (Redirects to dashboard)
└── README.md (Full documentation)
```

## Next Steps

1. ✅ Install dependencies
2. ✅ Start server
3. ✅ Open dashboard.html
4. ✅ Login and explore
5. ✅ Take a mock interview
6. ✅ Review feedback

Enjoy your interview prep! 🎯
