# API Response Examples

## 1. GET /questions/all
Returns all questions in the database with complete metadata.

**Response:**
```json
{
  "questions": [
    {
      "id": 1,
      "type": "mcq",
      "category": "Data Structures",
      "difficulty": "beginner",
      "question": "What is a data structure?",
      "options": [
        "A way to organize and store data efficiently",
        "A programming language",
        "A type of algorithm",
        "A database management system"
      ],
      "correctAnswer": "A way to organize and store data efficiently",
      "explanation": "A data structure is a specialized format for organizing, processing, retrieving and storing data..."
    },
    {
      "id": 11,
      "type": "normal",
      "category": "Data Structures",
      "difficulty": "beginner",
      "question": "Explain the difference between an array and a linked list.",
      "expectedKeywords": ["array", "linked list", "contiguous", "memory", "access time", "insertion", "deletion"],
      "explanation": "Arrays use contiguous memory and provide O(1) access but O(n) insertion/deletion..."
    }
  ],
  "count": 63
}
```

## 2. GET /categories
Returns list of all categories with question counts.

**Response:**
```json
{
  "categories": ["Data Structures", "Algorithms", "DBMS", "Python"],
  "count": 4
}
```

## 3. GET /questions/category/:categoryName
Returns all questions in a specific category.

**Example:** `GET /questions/category/Data%20Structures`

**Response:**
```json
{
  "category": "Data Structures",
  "count": 20,
  "questions": [
    // 20 questions in Data Structures category
  ]
}
```

## 4. GET /questions/random/:count
Returns random questions from the entire database.

**Example:** `GET /questions/random/5`

**Response:**
```json
{
  "count": 5,
  "questions": [
    // 5 random questions from all categories
  ]
}
```

## 5. POST /feedback
Submits interview responses and receives comprehensive feedback analysis.

**Request:**
```json
{
  "username": "student1",
  "responses": [
    {
      "questionId": 1,
      "answer": "A way to organize and store data efficiently",
      "type": "mcq"
    },
    {
      "questionId": 11,
      "answer": "Arrays store data in contiguous memory blocks allowing O(1) access time...",
      "type": "normal"
    }
  ]
}
```

**Response:**
```json
{
  "summary": {
    "totalQuestions": 2,
    "overallScore": 85,
    "performanceLevel": "Good",
    "timestamp": "2024-01-15T10:30:00.000Z"
  },
  "categoryWiseAnalysis": [
    {
      "category": "Data Structures",
      "score": 85,
      "totalQuestions": 2
    }
  ],
  "overallAnalysis": {
    "strengths": [
      "Strong understanding of fundamental data structure concepts",
      "Good knowledge of arrays and their properties"
    ],
    "weaknesses": [
      "Could improve on linked list comparison",
      "Need more practice on complex data structure operations"
    ],
    "summary": "You demonstrated a good grasp of basic data structures..."
  },
  "recommendations": [
    "Focus on implementation details of linked lists and binary search trees",
    "Practice advanced data structure problems on platform like LeetCode",
    "Review algorithm complexity analysis for better optimization skills"
  ],
  "detailedFeedback": [
    {
      "question": "What is a data structure?",
      "type": "mcq",
      "yourAnswer": "A way to organize and store data efficiently",
      "isCorrect": true,
      "correctAnswer": "A way to organize and store data efficiently",
      "explanation": "Correct! A data structure is indeed a specialized format for organizing data...",
      "score": 100
    },
    {
      "question": "Explain the difference between an array and a linked list.",
      "type": "normal",
      "yourAnswer": "Arrays store data in contiguous memory blocks allowing O(1) access time...",
      "score": 70,
      "explanation": "Good explanation! You correctly identified the contiguous memory aspect...",
      "matchedKeywords": ["array", "contiguous", "memory", "access", "time"],
      "missingKeywords": ["insertion", "deletion", "dynamic"]
    }
  ]
}
```

## Performance Levels

The system classifies performance as follows:

| Level | Score Range | Description |
|-------|-------------|-------------|
| Excellent | 90-100% | Outstanding knowledge and skills |
| Good | 70-89% | Strong understanding |
| Fair | 50-69% | Adequate knowledge |
| Average | 30-49% | Basic understanding |
| Needs Improvement | 0-29% | Requires significant study |

## Data Formats Explained

### MCQ Question Format
```javascript
{
  id: number,           // Unique identifier
  type: "mcq",         // Question type
  category: string,    // Category name
  difficulty: string,  // beginner, intermediate, or advanced
  question: string,    // The question text
  options: string[],   // Array of 4 options
  correctAnswer: string, // The correct option
  explanation: string  // Why this answer is correct
}
```

### Normal Q&A Question Format
```javascript
{
  id: number,                // Unique identifier
  type: "normal",           // Question type
  category: string,         // Category name
  difficulty: string,       // beginner, intermediate, or advanced
  question: string,         // The question text
  expectedKeywords: string[], // Keywords to look for in answer
  explanation: string       // Complete answer/explanation
}
```

### Response Format
```javascript
{
  questionId: number,  // ID of the question answered
  answer: string,      // User's answer
  type: string         // "mcq" or "normal"
}
```

## Evaluation Logic

### For MCQ Questions
- Answer is compared directly with correctAnswer
- Score: 100 if correct, 0 if incorrect

### For Normal Q&A Questions
- User's answer is searched for expectedKeywords
- Score calculation: (matchedKeywords / totalKeywords) * 100
- Minimum acceptable match: at least 50% of keywords

### Overall Score
- Average of all individual question scores
- Formula: (sum of all scores) / (number of questions) * 100

### Category-wise Score
- Average score for all questions in that category
- Helps identify strong and weak areas

## Error Responses

### 400 Bad Request
```json
{
  "error": "Missing required field",
  "field": "fieldName"
}
```

### 404 Not Found
```json
{
  "error": "Category not found",
  "category": "categoryName"
}
```

### 500 Server Error
```json
{
  "error": "Internal server error",
  "message": "error details"
}
```
