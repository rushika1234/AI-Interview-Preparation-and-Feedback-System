// Comprehensive Software Engineering Interview Questions
const softwareEngineeringQuestions = [
    // Object-Oriented Programming
    { question: 'What are the four main principles of Object-Oriented Programming?', category: 'OOP', difficulty: 'beginner' },
    { question: 'Explain the difference between inheritance and composition.', category: 'OOP', difficulty: 'intermediate' },
    { question: 'What is polymorphism and how is it different from method overloading?', category: 'OOP', difficulty: 'intermediate' },
    { question: 'What is encapsulation and why is it important?', category: 'OOP', difficulty: 'beginner' },
    { question: 'Explain the concept of abstraction in OOP.', category: 'OOP', difficulty: 'intermediate' },
    
    // Design Patterns
    { question: 'What is the Singleton design pattern and when should it be used?', category: 'Design Patterns', difficulty: 'intermediate' },
    { question: 'Explain the Factory design pattern.', category: 'Design Patterns', difficulty: 'intermediate' },
    { question: 'What is the Observer design pattern?', category: 'Design Patterns', difficulty: 'intermediate' },
    { question: 'Describe the MVC (Model-View-Controller) design pattern.', category: 'Design Patterns', difficulty: 'intermediate' },
    { question: 'What is the difference between the Adapter and Decorator design patterns?', category: 'Design Patterns', difficulty: 'advanced' },
    
    // SOLID Principles
    { question: 'What does SOLID stand for and explain each principle.', category: 'SOLID', difficulty: 'advanced' },
    { question: 'Explain the Single Responsibility Principle with an example.', category: 'SOLID', difficulty: 'intermediate' },
    { question: 'What is the Open/Closed Principle?', category: 'SOLID', difficulty: 'intermediate' },
    { question: 'Explain the Liskov Substitution Principle.', category: 'SOLID', difficulty: 'advanced' },
    { question: 'What is the Interface Segregation Principle?', category: 'SOLID', difficulty: 'intermediate' },
    
    // Software Development Lifecycle
    { question: 'What are the different phases of the Software Development Life Cycle (SDLC)?', category: 'SDLC', difficulty: 'beginner' },
    { question: 'Explain the differences between Waterfall and Agile methodologies.', category: 'SDLC', difficulty: 'intermediate' },
    { question: 'What is the importance of requirements gathering in software development?', category: 'SDLC', difficulty: 'beginner' },
    { question: 'Describe the Agile methodology and its advantages.', category: 'SDLC', difficulty: 'intermediate' },
    { question: 'What is DevOps and how does it improve software development?', category: 'SDLC', difficulty: 'advanced' },
    
    // Database Design
    { question: 'What is database normalization and why is it important?', category: 'Database', difficulty: 'intermediate' },
    { question: 'Explain the difference between SQL and NoSQL databases.', category: 'Database', difficulty: 'intermediate' },
    { question: 'What are the different normal forms in database normalization?', category: 'Database', difficulty: 'advanced' },
    { question: 'What is an index in a database and how does it improve performance?', category: 'Database', difficulty: 'intermediate' },
    { question: 'Explain the ACID properties in database transactions.', category: 'Database', difficulty: 'advanced' },
    
    // Software Architecture
    { question: 'What is software architecture and why is it important?', category: 'Architecture', difficulty: 'beginner' },
    { question: 'Explain the microservices architecture pattern.', category: 'Architecture', difficulty: 'advanced' },
    { question: 'What is a monolithic architecture and what are its disadvantages?', category: 'Architecture', difficulty: 'intermediate' },
    { question: 'Describe the difference between horizontal and vertical scaling.', category: 'Architecture', difficulty: 'intermediate' },
    { question: 'What is the importance of API design in software architecture?', category: 'Architecture', difficulty: 'intermediate' },
    
    // Testing
    { question: 'What are the different types of software testing?', category: 'Testing', difficulty: 'beginner' },
    { question: 'Explain the difference between unit testing and integration testing.', category: 'Testing', difficulty: 'intermediate' },
    { question: 'What is test-driven development (TDD)?', category: 'Testing', difficulty: 'intermediate' },
    { question: 'What is code coverage and why is it important?', category: 'Testing', difficulty: 'intermediate' },
    { question: 'Explain the concept of mocking in unit testing.', category: 'Testing', difficulty: 'advanced' },
    
    // Version Control
    { question: 'What is Git and how does it differ from other version control systems?', category: 'Version Control', difficulty: 'beginner' },
    { question: 'Explain the concept of branching in Git.', category: 'Version Control', difficulty: 'beginner' },
    { question: 'What is the difference between merge and rebase in Git?', category: 'Version Control', difficulty: 'intermediate' },
    { question: 'How do you resolve merge conflicts in Git?', category: 'Version Control', difficulty: 'intermediate' },
    { question: 'What is a pull request and how is it used in collaborative development?', category: 'Version Control', difficulty: 'intermediate' },
    
    // Security
    { question: 'What are the common security vulnerabilities in web applications?', category: 'Security', difficulty: 'intermediate' },
    { question: 'Explain SQL injection and how to prevent it.', category: 'Security', difficulty: 'intermediate' },
    { question: 'What is Cross-Site Scripting (XSS) and how can it be prevented?', category: 'Security', difficulty: 'intermediate' },
    { question: 'What is authentication and how is it different from authorization?', category: 'Security', difficulty: 'beginner' },
    { question: 'Explain the concept of encryption and its types.', category: 'Security', difficulty: 'intermediate' },
    
    // Performance Optimization
    { question: 'What are the common performance bottlenecks in software applications?', category: 'Performance', difficulty: 'intermediate' },
    { question: 'Explain the concept of caching and its types.', category: 'Performance', difficulty: 'intermediate' },
    { question: 'What is the importance of profiling in performance optimization?', category: 'Performance', difficulty: 'advanced' },
    { question: 'How can you optimize database queries for better performance?', category: 'Performance', difficulty: 'intermediate' },
    { question: 'What are the best practices for reducing application load times?', category: 'Performance', difficulty: 'intermediate' },
    
    // Problem Solving
    { question: 'How do you approach solving a complex problem in software development?', category: 'Problem Solving', difficulty: 'intermediate' },
    { question: 'What is the importance of code review in ensuring software quality?', category: 'Problem Solving', difficulty: 'beginner' },
    { question: 'Describe your debugging process when you encounter a bug.', category: 'Problem Solving', difficulty: 'intermediate' },
    { question: 'How do you handle technical debt in a project?', category: 'Problem Solving', difficulty: 'advanced' },
    { question: 'What strategies do you use for refactoring legacy code?', category: 'Problem Solving', difficulty: 'advanced' }
];

module.exports = softwareEngineeringQuestions;
