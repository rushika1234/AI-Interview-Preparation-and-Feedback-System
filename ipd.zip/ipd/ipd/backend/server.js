const express = require('express');
const path = require('path');
const fs = require('fs');
const app = express();
const port = 3000;
const expandedQuestions = require('./expandedQuestions');
const bTechQuestions = require('./bTechQuestions');

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    next();
});

// Middleware to parse JSON
app.use(express.json());

// Evaluate a written answer immediately during AI Interview mode.
app.post('/ai-interview/feedback', async (req, res) => {
    const { question, answer } = req.body || {};
    if (!question || typeof answer !== 'string' || !answer.trim()) {
        return res.status(400).json({ message: 'A question and written answer are required.' });
    }

    if (process.env.OPENAI_API_KEY) {
        try {
            const prompt = `Evaluate this interview answer. Question: ${question.question}\nExpected concepts: ${(question.expectedKeywords || []).join(', ')}\nAnswer: ${answer}\nReturn only JSON with score (0-100), feedback (one sentence), and suggestions (array of short strings).`;
            const response = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
                },
                body: JSON.stringify({
                    model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
                    messages: [{ role: 'user', content: prompt }],
                    response_format: { type: 'json_object' },
                    temperature: 0.2,
                    max_tokens: 250
                })
            });
            if (!response.ok) throw new Error(`OpenAI request failed: ${response.status}`);
            const result = await response.json();
            const parsed = JSON.parse(result.choices[0].message.content);
            return res.json({
                score: Math.max(0, Math.min(100, Number(parsed.score) || 0)),
                feedback: String(parsed.feedback || 'Review the answer and try again.'),
                suggestions: Array.isArray(parsed.suggestions) ? parsed.suggestions : [],
                source: 'openai'
            });
        } catch (error) {
            console.warn('AI provider unavailable; using local evaluation:', error.message);
        }
    }

    const keywords = Array.isArray(question.expectedKeywords) ? question.expectedKeywords : [];
    const normalizedAnswer = answer.toLowerCase();
    const matchedKeywords = keywords.filter(keyword => normalizedAnswer.includes(String(keyword).toLowerCase()));
    const score = keywords.length ? Math.min(100, Math.round(matchedKeywords.length / keywords.length * 100)) : 50;
    const suggestions = [];

    if (answer.trim().split(/\s+/).length < 12) suggestions.push('Add a little more detail and explain your reasoning.');
    if (keywords.length && matchedKeywords.length < keywords.length) {
        suggestions.push(`Cover these ideas: ${keywords.filter(keyword => !matchedKeywords.includes(keyword)).join(', ')}.`);
    }
    if (!suggestions.length) suggestions.push('Keep the structure clear and support the explanation with a concrete example.');

    res.json({
        score,
        feedback: score >= 75
            ? 'Strong answer. You addressed the key ideas expected for this question.'
            : score >= 50
                ? 'Good starting point, but the answer would benefit from more complete coverage.'
                : 'The answer needs more of the core concepts expected for this question.',
        suggestions,
        source: 'local-evaluation'
    });
});

// In-memory questions storage
let questionsDB = [];

// AUTO-LOAD QUESTIONS ON STARTUP
questionsDB = [...expandedQuestions];
console.log(`Questions loaded: ${questionsDB.length}`);

// Ensure each category has at least N questions by generating variants
function ensureMinPerCategory(minCount){
    const categories = Array.from(new Set(questionsDB.map(q=>q.category)));
    let addedTotal = 0;
    categories.forEach(cat => {
        const existing = questionsDB.filter(q=>q.category===cat);
        const need = Math.max(0, minCount - existing.length);
        if(need>0){
            const generated = generateQuestionsForCategory(cat, need);
            questionsDB.push(...generated);
            addedTotal += generated.length;
            console.log(`Added ${generated.length} generated questions for category '${cat}' (now ${existing.length+generated.length})`);
        }
    });
    if(addedTotal>0) console.log(`Auto-generated ${addedTotal} questions to meet minimum per category (${minCount}).`);
}

// Auto-fill to 100 per category on startup
ensureMinPerCategory(100);

// --- User assignments storage (simple JSON persistence) ---
const userDataDir = path.join(__dirname, 'data');
const userAssignFile = path.join(userDataDir, 'user_questions.json');
if (!fs.existsSync(userDataDir)) fs.mkdirSync(userDataDir, { recursive: true });
let userAssignments = {};
try{
    if (fs.existsSync(userAssignFile)) userAssignments = JSON.parse(fs.readFileSync(userAssignFile,'utf8')) || {};
}catch(e){ console.warn('Failed to read user assignments:', e.message); userAssignments = {}; }

function saveUserAssignments(){
    try{ fs.writeFileSync(userAssignFile, JSON.stringify(userAssignments, null, 2)); }catch(e){ console.warn('Failed to save user assignments:', e.message); }
}

function makeId(){ return Date.now().toString(36) + Math.random().toString(36).slice(2,8); }

// Simple generator: create varied questions based on category templates
function generateQuestionsForCategory(category, count){
    const templates = questionsDB.filter(q => q.category === category).map(q => q.question);
    const pool = [];
    for(let i=0;i<count;i++){
        const base = templates[i % templates.length] || `${category} question`;
        // add slight variation
        const variant = base.includes('?') ? base.replace('?', ` (variant ${i+1})?`) : `${base} (variant ${i+1})`;
        pool.push({
            id: makeId(),
            type: 'normal',
            question: variant,
            category,
            difficulty: 'mixed',
            expectedKeywords: [],
            explanation: 'This generated question does not have a model answer yet.'
        });
    }
    return pool;
}

// Assign or extend questions for a user
app.post('/user/:username/generate', (req, res) => {
    const username = req.params.username;
    const category = req.body.category || req.query.category || 'Data Structures';
    const count = parseInt(req.body.count || req.query.count || '100');
    if(!username) return res.status(400).json({ error: 'missing username' });

    userAssignments[username] = userAssignments[username] || {};
    userAssignments[username][category] = userAssignments[username][category] || [];

    // generate new questions and ensure uniqueness by id
    const newQuestions = generateQuestionsForCategory(category, count);
    // avoid duplicates by simple text compare
    const existingTexts = new Set(userAssignments[username][category].map(q=>q.question));
    const toAdd = newQuestions.filter(q => !existingTexts.has(q.question));
    userAssignments[username][category].push(...toAdd);
    saveUserAssignments();

    res.json({ username, category, totalAssigned: userAssignments[username][category].length, assigned: toAdd.length });
});

// Fetch assigned questions for user
app.get('/user/:username/questions', (req, res) => {
    const username = req.params.username;
    const category = req.query.category;
    if(!username) return res.status(400).json({ error: 'missing username' });
    const user = userAssignments[username] || {};
    if(category) return res.json({ username, category, questions: user[category] || [] });
    res.json({ username, questions: user });
});

// Route: Home
app.get('/', (req, res) => {
    res.send('Welcome to AI Interview Preparation System - B.Tech Software Engineering');
});

// Route: Add all B.Tech questions
app.post('/add-all-questions', (req, res) => {
    try {
        console.log('Starting to load questions...');
        console.log('bTechQuestions type:', typeof bTechQuestions);
        console.log('bTechQuestions length:', bTechQuestions.length);
        
        if (!Array.isArray(bTechQuestions)) {
            throw new Error('Questions is not an array');
        }
        
        questionsDB = [...bTechQuestions];
        console.log(`Successfully loaded ${questionsDB.length} questions into memory`);
        
        res.json({
            message: `Successfully added ${questionsDB.length} interview questions!`,
            totalQuestions: questionsDB.length,
            categories: {
                'Data Structures': 5,
                'Algorithms': 5,
                'DBMS': 5,
                'Operating Systems': 5,
                'Computer Networks': 5
            }
        });
    } catch (error) {
        console.error('Error adding questions:', error.message);
        console.error('Stack:', error.stack);
        res.status(500).json({ 
            message: 'Failed to add questions.', 
            error: error.message,
            stack: error.stack
        });
    }
});

// Route: Get all categories
app.get('/categories', (req, res) => {
    const categories = ['Data Structures', 'Algorithms', 'DBMS', 'Operating Systems', 'Computer Networks', 'Web Development', 'Software Engineering'];
    res.json({ categories: categories });
});

// Route: Get questions by category
app.get('/questions/category/:category', (req, res) => {
    try {
        const { category } = req.params;
        const questions = questionsDB.filter(q => q.category === category);
        res.json({
            category: category,
            totalQuestions: questions.length,
            questions: questions
        });
    } catch (error) {
        res.status(500).json({ message: 'Failed to fetch questions.' });
    }
});

// Route: Get questions by difficulty
app.get('/questions/difficulty/:difficulty', (req, res) => {
    try {
        const { difficulty } = req.params;
        const questions = questionsDB.filter(q => q.difficulty === difficulty);
        res.json({
            difficulty: difficulty,
            totalQuestions: questions.length,
            questions: questions
        });
    } catch (error) {
        res.status(500).json({ message: 'Failed to fetch questions.' });
    }
});

// Route: Get random questions
app.get('/questions/random/:count', (req, res) => {
    try {
        const { count } = req.params;
        const numCount = parseInt(count);
        const shuffled = [...questionsDB].sort(() => Math.random() - 0.5);
        const questions = shuffled.slice(0, numCount);
        
        res.json({
            totalQuestions: questions.length,
            questions: questions
        });
    } catch (error) {
        res.status(500).json({ message: 'Failed to fetch random questions.' });
    }
});

// Route: Get random questions by category
app.get('/questions/random/:category/:count', (req, res) => {
    try {
        const { category, count } = req.params;
        const numCount = parseInt(count);
        const categoryQuestions = questionsDB.filter(q => q.category === category);
        const shuffled = categoryQuestions.sort(() => Math.random() - 0.5);
        const questions = shuffled.slice(0, numCount);
        
        res.json({
            category: category,
            totalQuestions: questions.length,
            questions: questions
        });
    } catch (error) {
        res.status(500).json({ message: 'Failed to fetch random questions.' });
    }
});

// Route: Get all questions
app.get('/questions/all', (req, res) => {
    res.json({
        totalQuestions: questionsDB.length,
        questions: questionsDB
    });
});

// Route: Conduct mock interview
app.post('/mock-interview', (req, res) => {
    const { username, questions } = req.body;
    const responses = questions.map((question, index) => ({
        question: question,
        response: `Sample response for question ${index + 1}`
    }));

    res.json({
        message: `Mock interview conducted for ${username}`,
        totalQuestions: questions.length,
        responses: responses
    });
});

// Route: Provide feedback
app.post('/feedback', (req, res) => {
    const { username, responses } = req.body;

    let mcqScore = 0;
    let normalScore = 0;
    let mcqCount = 0;
    let normalCount = 0;
    let categoryWiseScore = {};

    // Calculate scores
    responses.forEach(response => {
        const question = questionsDB.find(q => q.id === response.questionId);
        if (!question) return;

        // Initialize category if not exists
        if (!categoryWiseScore[question.category]) {
            categoryWiseScore[question.category] = { total: 0, scored: 0 };
        }

        if (question.type === 'mcq') {
            mcqCount++;
            const isCorrect = response.answer === question.correctAnswer;
            if (isCorrect) {
                mcqScore += 100;
            }
            categoryWiseScore[question.category].total += 100;
            categoryWiseScore[question.category].scored += isCorrect ? 100 : 0;
        } else {
            normalCount++;
            const score = evaluateNormalAnswer(response.answer, question.expectedKeywords);
            normalScore += score;
            categoryWiseScore[question.category].total += 100;
            categoryWiseScore[question.category].scored += score;
        }
    });

    // Calculate overall statistics
    const totalQuestions = responses.length;
    const totalScore = mcqScore + normalScore;
    const averageScore = Math.round(totalScore / totalQuestions);

    // Generate analysis
    const analysis = generateAnalysis(averageScore, categoryWiseScore);

    res.json({
        message: `Interview completed for ${username}`,
        summary: {
            totalQuestions: totalQuestions,
            overallScore: averageScore,
            performanceLevel: getPerformanceLevel(averageScore),
            timestamp: new Date().toISOString()
        },
        categoryWiseAnalysis: Object.entries(categoryWiseScore).map(([cat, score]) => ({
            category: cat,
            score: Math.round(score.scored / score.total * 100),
            totalQuestions: responses.filter(r => {
                const q = questionsDB.find(x => x.id === r.questionId);
                return q && q.category === cat;
            }).length
        })),
        overallAnalysis: analysis,
        recommendations: generateRecommendations(averageScore, categoryWiseScore),
        detailedFeedback: generateDetailedFeedback(responses)
    });
});

// Helper function to evaluate normal answers
function evaluateNormalAnswer(answer, expectedKeywords) {
    if (!answer || answer.toLowerCase().includes('skipped')) return 0;

    const answerWords = answer.toLowerCase().split(/\s+/);
    const keywordMatches = expectedKeywords.filter(keyword =>
        answerWords.join(' ').includes(keyword.toLowerCase())
    ).length;

    const score = Math.round((keywordMatches / expectedKeywords.length) * 100);
    return Math.min(score, 100);
}

// Generate performance level
function getPerformanceLevel(score) {
    if (score >= 90) return 'Excellent';
    if (score >= 75) return 'Good';
    if (score >= 60) return 'Fair';
    if (score >= 45) return 'Average';
    return 'Needs Improvement';
}

// Generate overall analysis
function generateAnalysis(score, categoryWiseScore) {
    const analysis = {
        strengths: [],
        weaknesses: [],
        summary: ''
    };

    // Identify strengths and weaknesses
    Object.entries(categoryWiseScore).forEach(([cat, scores]) => {
        const categoryScore = Math.round(scores.scored / scores.total * 100);
        if (categoryScore >= 80) {
            analysis.strengths.push(`${cat}: ${categoryScore}%`);
        } else if (categoryScore < 50) {
            analysis.weaknesses.push(`${cat}: ${categoryScore}%`);
        }
    });

    if (score >= 85) {
        analysis.summary = 'Outstanding performance! You demonstrated excellent understanding across topics.';
    } else if (score >= 70) {
        analysis.summary = 'Good performance! You have solid understanding but can improve in certain areas.';
    } else if (score >= 50) {
        analysis.summary = 'Moderate performance. Focus on the weak areas identified to improve further.';
    } else {
        analysis.summary = 'Keep practicing! Regular practice and revision will help improve your scores.';
    }

    return analysis;
}

// Generate recommendations
function generateRecommendations(score, categoryWiseScore) {
    const recommendations = [];

    Object.entries(categoryWiseScore).forEach(([cat, scores]) => {
        const categoryScore = Math.round(scores.scored / scores.total * 100);
        if (categoryScore < 60) {
            recommendations.push(`Focus on ${cat} - Current: ${categoryScore}% - Try practicing more questions in this category`);
        }
    });

    if (score < 50) {
        recommendations.push('Take time to thoroughly study the concepts before attempting interviews');
    }
    if (score < 70 && score >= 50) {
        recommendations.push('Review your weak areas and practice similar questions');
    }
    if (score >= 80) {
        recommendations.push('Great work! Challenge yourself with advanced difficulty questions');
    }

    return recommendations.length > 0 ? recommendations : ['Keep up the good work!'];
}

// Generate detailed feedback
function generateDetailedFeedback(responses) {
    return responses.map(response => {
        const question = questionsDB.find(q => q.id === response.questionId);
        if (!question) return null;

        if (question.type === 'mcq') {
            return {
                question: question.question,
                yourAnswer: response.answer,
                correctAnswer: question.correctAnswer,
                isCorrect: response.answer === question.correctAnswer,
                explanation: question.explanation,
                type: 'mcq'
            };
        } else {
            const score = evaluateNormalAnswer(response.answer, question.expectedKeywords);
            return {
                question: question.question,
                yourAnswer: response.answer || 'No response',
                score: score,
                expectedKeywords: question.expectedKeywords,
                explanation: question.explanation,
                type: 'normal'
            };
        }
    }).filter(f => f !== null);
}

// Start the server
app.listen(port, () => {
    console.log(`\n========== SERVER STARTED ==========`);
    console.log(`Server is running on http://localhost:${port}`);
    console.log(`Questions loaded: ${questionsDB.length}`);
    console.log(`Is array: ${Array.isArray(questionsDB)}`);
    console.log(`CORS Enabled for all origins`);
    console.log(`First question: ${questionsDB[0] ? questionsDB[0].question : 'NONE'}`);
    console.log(`=====================================\n`);
});