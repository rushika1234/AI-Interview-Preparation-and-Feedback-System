const express = require('express');
const app = express();
const port = 3000;
const { Question } = require('./database');
const softwareEngineeringQuestions = require('./interviewQuestions');

// Middleware to parse JSON
app.use(express.json());

// Basic route
app.get('/', (req, res) => {
    res.send('Welcome to the AI Interview Preparation System Backend!');
});

// Route to add all software engineering interview questions to database
app.post('/add-all-questions', async (req, res) => {
    try {
        await Question.insertMany(softwareEngineeringQuestions);
        res.json({ 
            message: `Successfully added ${softwareEngineeringQuestions.length} software engineering interview questions!`,
            totalQuestions: softwareEngineeringQuestions.length
        });
    } catch (error) {
        console.error('Error adding questions:', error);
        res.status(500).json({ message: 'Failed to add questions.' });
    }
});

// Route to get questions by category
app.get('/questions/category/:category', async (req, res) => {
    try {
        const { category } = req.params;
        const questions = await Question.find({ category: category });
        res.json({ 
            category: category,
            totalQuestions: questions.length,
            questions: questions 
        });
    } catch (error) {
        console.error('Error fetching questions:', error);
        res.status(500).json({ message: 'Failed to fetch questions.' });
    }
});

// Route to get questions by difficulty level
app.get('/questions/difficulty/:difficulty', async (req, res) => {
    try {
        const { difficulty } = req.params;
        const questions = await Question.find({ difficulty: difficulty });
        res.json({ 
            difficulty: difficulty,
            totalQuestions: questions.length,
            questions: questions 
        });
    } catch (error) {
        console.error('Error fetching questions:', error);
        res.status(500).json({ message: 'Failed to fetch questions.' });
    }
});

// Route to get all questions
app.get('/questions/all', async (req, res) => {
    try {
        const questions = await Question.find({});
        res.json({ 
            totalQuestions: questions.length,
            questions: questions 
        });
    } catch (error) {
        console.error('Error fetching questions:', error);
        res.status(500).json({ message: 'Failed to fetch questions.' });
    }
});

// Route to get random questions for mock interview
app.get('/questions/random/:count', async (req, res) => {
    try {
        const { count } = req.params;
        const questions = await Question.aggregate([{ $sample: { size: parseInt(count) } }]);
        res.json({ 
            totalQuestions: questions.length,
            questions: questions 
        });
    } catch (error) {
        console.error('Error fetching random questions:', error);
        res.status(500).json({ message: 'Failed to fetch random questions.' });
    }
});

// Route to conduct a mock interview
app.post('/mock-interview', (req, res) => {
    const { username, questions } = req.body;

    // Simulate mock interview process
    const responses = questions.map((question, index) => ({
        question: question,
        response: `Sample response for question ${index + 1}`
    }));

    res.json({
        message: `Mock interview conducted for ${username}`,
        responses: responses
    });
});

// Route to provide feedback
app.post('/feedback', (req, res) => {
    const { username, responses } = req.body;

    // Simulate feedback generation
    const feedback = responses.map((response, index) => ({
        question: response.question,
        feedback: `Feedback for response ${index + 1}`
    }));

    res.json({
        message: `Feedback generated for ${username}`,
        feedback: feedback
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});