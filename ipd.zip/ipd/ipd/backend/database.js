const mongoose = require('mongoose');

// MongoDB connection URI
const uri = 'mongodb://localhost:27017/ai_interview_system';

// Connect to MongoDB
mongoose.connect(uri)
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => console.error('Failed to connect to MongoDB', err));

// User schema
const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true },
});

// Question schema
const questionSchema = new mongoose.Schema({
    question: { type: String, required: true },
    category: { type: String },
});

// Feedback schema
const feedbackSchema = new mongoose.Schema({
    username: { type: String, required: true },
    responses: [{
        question: String,
        response: String,
        feedback: String
    }]
});

// Models
const User = mongoose.model('User', userSchema);
const Question = mongoose.model('Question', questionSchema);
const Feedback = mongoose.model('Feedback', feedbackSchema);

module.exports = { User, Question, Feedback };