// Simplified Interview Questions - Testing Version
const questions = [
    // Data Structures
    { question: 'What is a data structure?', category: 'Data Structures', difficulty: 'beginner', subject: 'DSA' },
    { question: 'Explain the difference between array and linked list.', category: 'Data Structures', difficulty: 'beginner', subject: 'DSA' },
    { question: 'What is a stack and what are its applications?', category: 'Data Structures', difficulty: 'beginner', subject: 'DSA' },
    { question: 'Explain the concept of a queue and its types.', category: 'Data Structures', difficulty: 'beginner', subject: 'DSA' },
    { question: 'What is a binary tree and how does it differ from a binary search tree?', category: 'Data Structures', difficulty: 'intermediate', subject: 'DSA' },
    
    // Algorithms
    { question: 'What is Big O notation and why is it important?', category: 'Algorithms', difficulty: 'beginner', subject: 'Algorithms' },
    { question: 'Explain the differences between O(n), O(n²), and O(log n) time complexities.', category: 'Algorithms', difficulty: 'intermediate', subject: 'Algorithms' },
    { question: 'Describe the bubble sort algorithm and its time complexity.', category: 'Algorithms', difficulty: 'beginner', subject: 'Algorithms' },
    { question: 'Explain the selection sort algorithm.', category: 'Algorithms', difficulty: 'beginner', subject: 'Algorithms' },
    { question: 'What is insertion sort and how does it work?', category: 'Algorithms', difficulty: 'beginner', subject: 'Algorithms' },
    
    // DBMS
    { question: 'What is a database and its advantages?', category: 'DBMS', difficulty: 'beginner', subject: 'DBMS' },
    { question: 'Explain the relational database model.', category: 'DBMS', difficulty: 'intermediate', subject: 'DBMS' },
    { question: 'What is a table, row, and column in a relational database?', category: 'DBMS', difficulty: 'beginner', subject: 'DBMS' },
    { question: 'Describe what a primary key is and its importance.', category: 'DBMS', difficulty: 'intermediate', subject: 'DBMS' },
    { question: 'What is a foreign key and how is it used?', category: 'DBMS', difficulty: 'intermediate', subject: 'DBMS' },
    
    // OS
    { question: 'What is an operating system and its functions?', category: 'Operating Systems', difficulty: 'beginner', subject: 'OS' },
    { question: 'What is a process in an operating system?', category: 'Operating Systems', difficulty: 'beginner', subject: 'OS' },
    { question: 'Explain the concept of a thread.', category: 'Operating Systems', difficulty: 'intermediate', subject: 'OS' },
    { question: 'What is the difference between a process and a thread?', category: 'Operating Systems', difficulty: 'intermediate', subject: 'OS' },
    { question: 'Describe multithreading and its advantages.', category: 'Operating Systems', difficulty: 'intermediate', subject: 'OS' },
    
    // Networks
    { question: 'What is a computer network and its advantages?', category: 'Computer Networks', difficulty: 'beginner', subject: 'CN' },
    { question: 'Explain the OSI model and its seven layers.', category: 'Computer Networks', difficulty: 'intermediate', subject: 'CN' },
    { question: 'What is the TCP/IP model?', category: 'Computer Networks', difficulty: 'intermediate', subject: 'CN' },
    { question: 'What is HTTP and HTTPS?', category: 'Computer Networks', difficulty: 'intermediate', subject: 'CN' },
    { question: 'Explain DNS protocol.', category: 'Computer Networks', difficulty: 'beginner', subject: 'CN' },
];

module.exports = questions;
