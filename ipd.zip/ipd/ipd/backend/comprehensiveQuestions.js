const comprehensiveQuestions = [
    // ==================== DATA STRUCTURES (50+ questions) ====================

    // MCQs - Data Structures
    {
        id: 1,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'beginner',
        question: 'What is a data structure?',
        options: [
            'A way to organize and store data efficiently',
            'A programming language',
            'A type of algorithm',
            'A database management system'
        ],
        correctAnswer: 'A way to organize and store data efficiently',
        explanation: 'A data structure is a specialized format for organizing, processing, retrieving and storing data. Common examples include arrays, linked lists, trees, and graphs.'
    },
    {
        id: 2,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'beginner',
        question: 'Which of the following is a linear data structure?',
        options: [
            'Tree',
            'Graph',
            'Array',
            'All of the above'
        ],
        correctAnswer: 'Array',
        explanation: 'Linear data structures have elements arranged in a line. Arrays, linked lists, stacks, and queues are examples. Trees and graphs are non-linear structures.'
    },
    {
        id: 3,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'beginner',
        question: 'What is the time complexity of accessing an element in an array by index?',
        options: [
            'O(log n)',
            'O(n)',
            'O(1)',
            'O(n²)'
        ],
        correctAnswer: 'O(1)',
        explanation: 'Arrays provide constant time access to elements using the index. This is because array elements are stored in contiguous memory locations.'
    },
    {
        id: 4,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'A stack follows which principle?',
        options: [
            'FIFO (First In First Out)',
            'LIFO (Last In First Out)',
            'Random Access',
            'Priority based'
        ],
        correctAnswer: 'LIFO (Last In First Out)',
        explanation: 'Stack follows LIFO principle where the last element added is the first one to be removed, like a stack of plates.'
    },
    {
        id: 5,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'A queue follows which principle?',
        options: [
            'LIFO (Last In First Out)',
            'FIFO (First In First Out)',
            'Random Access',
            'Priority based'
        ],
        correctAnswer: 'FIFO (First In First Out)',
        explanation: 'Queue follows FIFO principle where the first element added is the first one to be removed, like a line in a store.'
    },
    {
        id: 6,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'What is the worst-case time complexity of searching in a linked list?',
        options: [
            'O(1)',
            'O(log n)',
            'O(n)',
            'O(n²)'
        ],
        correctAnswer: 'O(n)',
        explanation: 'In a linked list, we need to traverse from the head node, so searching requires O(n) time in the worst case.'
    },
    {
        id: 7,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'What is a hash table?',
        options: [
            'A data structure that implements associative array',
            'A type of tree',
            'A type of graph',
            'A sorting algorithm'
        ],
        correctAnswer: 'A data structure that implements associative array',
        explanation: 'A hash table uses a hash function to compute an index into an array of buckets or slots, from which the desired value can be found.'
    },
    {
        id: 8,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'What is a collision in a hash table?',
        options: [
            'When two keys have the same hash value',
            'When the hash table is full',
            'When an element is not found',
            'When two elements have the same value'
        ],
        correctAnswer: 'When two keys have the same hash value',
        explanation: 'A collision occurs when two different keys hash to the same index. Techniques like chaining and open addressing are used to handle collisions.'
    },
    {
        id: 9,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'advanced',
        question: 'What is the average case time complexity of a binary search tree operation (search, insert, delete)?',
        options: [
            'O(1)',
            'O(log n)',
            'O(n)',
            'O(n log n)'
        ],
        correctAnswer: 'O(log n)',
        explanation: 'In a balanced binary search tree, operations have O(log n) average case complexity. However, in a skewed tree, it can degrade to O(n).'
    },
    {
        id: 10,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'advanced',
        question: 'Which data structure is used to implement a priority queue efficiently?',
        options: [
            'Array',
            'Linked List',
            'Heap',
            'Stack'
        ],
        correctAnswer: 'Heap',
        explanation: 'A heap is a complete binary tree that satisfies the heap property. Min-heap or max-heap is efficiently used to implement priority queues.'
    },

    // Normal Q&A - Data Structures
    {
        id: 11,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'beginner',
        question: 'Explain the difference between an array and a linked list.',
        expectedKeywords: ['array', 'linked list', 'contiguous', 'memory', 'access time', 'insertion', 'deletion', 'static', 'dynamic'],
        explanation: 'Arrays use contiguous memory and provide O(1) access but O(n) insertion/deletion. Linked lists use non-contiguous memory, O(n) access but O(1) insertion/deletion at known positions.'
    },
    {
        id: 12,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'beginner',
        question: 'What is the difference between a stack and a queue?',
        expectedKeywords: ['LIFO', 'FIFO', 'Last In First Out', 'First In First Out', 'push', 'pop', 'enqueue', 'dequeue'],
        explanation: 'Stack (LIFO): Last inserted element is removed first. Queue (FIFO): First inserted element is removed first. Stack uses push/pop, queue uses enqueue/dequeue.'
    },
    {
        id: 13,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'Explain the concept of tree and its terminologies.',
        expectedKeywords: ['tree', 'root', 'leaf', 'node', 'edge', 'parent', 'child', 'height', 'depth', 'subtree'],
        explanation: 'A tree is a hierarchical data structure with a root node. Terminologies include: root (top node), leaf (node with no children), height (longest path from root), depth (distance from root).'
    },
    {
        id: 14,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'What is a binary search tree? Explain its properties.',
        expectedKeywords: ['binary search tree', 'BST', 'left', 'right', 'smaller', 'larger', 'ordered', 'search', 'properties'],
        explanation: 'BST is a binary tree where for each node, all left subtree values are smaller and all right subtree values are larger. This property enables efficient searching.'
    },
    {
        id: 15,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'What is a graph? Explain directed and undirected graphs.',
        expectedKeywords: ['graph', 'vertices', 'edges', 'directed', 'undirected', 'arrows', 'connections', 'nodes'],
        explanation: 'A graph is a collection of vertices (nodes) connected by edges. Directed graphs have arrows showing direction; undirected graphs have bidirectional connections.'
    },
    {
        id: 16,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'advanced',
        question: 'Explain the concept of hashing and hash functions.',
        expectedKeywords: ['hashing', 'hash function', 'key', 'value', 'collision', 'distributed', 'uniform', 'deterministic'],
        explanation: 'Hashing maps keys to array indices using a hash function. A good hash function distributes keys uniformly. Collisions occur when different keys hash to the same index.'
    },
    {
        id: 17,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'advanced',
        question: 'What are different collision resolution techniques in hashing?',
        expectedKeywords: ['collision resolution', 'chaining', 'open addressing', 'linear probing', 'quadratic probing', 'double hashing'],
        explanation: 'Main techniques: Chaining (linked list at each bucket) and Open Addressing (find empty slot). Variants of open addressing include linear probing and quadratic probing.'
    },
    {
        id: 18,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'advanced',
        question: 'Explain the concept of a heap and its types.',
        expectedKeywords: ['heap', 'min-heap', 'max-heap', 'complete binary tree', 'parent', 'child', 'priority'],
        explanation: 'A heap is a complete binary tree where parent nodes are either greater (max-heap) or smaller (min-heap) than children. Used for priority queues and sorting.'
    },
    {
        id: 19,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'What is the difference between a balanced and unbalanced tree?',
        expectedKeywords: ['balanced', 'unbalanced', 'height', 'skewed', 'operations', 'efficiency', 'AVL', 'Red-Black'],
        explanation: 'Balanced trees maintain roughly equal height, ensuring O(log n) operations. Unbalanced trees can become skewed, degrading to O(n). Examples: AVL, Red-Black trees.'
    },
    {
        id: 20,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'Explain dynamic array and how it handles overflow.',
        expectedKeywords: ['dynamic array', 'ArrayList', 'Vector', 'capacity', 'reallocation', 'amortized', 'doubling', 'growth'],
        explanation: 'Dynamic arrays grow automatically when full. When overflow occurs, a new larger array is allocated (usually double the size) and elements are copied. This provides amortized O(1) insertion.'
    },

    // ==================== ALGORITHMS (50+ questions) ====================

    // MCQs - Algorithms
    {
        id: 101,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'beginner',
        question: 'What is an algorithm?',
        options: [
            'A step-by-step procedure to solve a problem',
            'A programming language',
            'A data structure',
            'A type of database'
        ],
        correctAnswer: 'A step-by-step procedure to solve a problem',
        explanation: 'An algorithm is a finite set of well-defined instructions or steps to accomplish a task or solve a problem.'
    },
    {
        id: 102,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'beginner',
        question: 'Which sorting algorithm is the simplest?',
        options: [
            'Quick Sort',
            'Merge Sort',
            'Bubble Sort',
            'Heap Sort'
        ],
        correctAnswer: 'Bubble Sort',
        explanation: 'Bubble sort is the simplest sorting algorithm. It repeatedly steps through the list, compares adjacent elements, and swaps them if needed.'
    },
    {
        id: 103,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'beginner',
        question: 'What is the time complexity of binary search?',
        options: [
            'O(1)',
            'O(log n)',
            'O(n)',
            'O(n²)'
        ],
        correctAnswer: 'O(log n)',
        explanation: 'Binary search has O(log n) time complexity as it divides the search space in half with each comparison. Works on sorted arrays.'
    },
    {
        id: 104,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'Which sorting algorithm has the best average case time complexity?',
        options: [
            'Bubble Sort - O(n²)',
            'Insertion Sort - O(n²)',
            'Merge Sort - O(n log n)',
            'Selection Sort - O(n²)'
        ],
        correctAnswer: 'Merge Sort - O(n log n)',
        explanation: 'Merge Sort has O(n log n) average, best, and worst-case time complexity. It uses divide-and-conquer approach.'
    },
    {
        id: 105,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'What is the main difference between greedy and dynamic programming?',
        options: [
            'Greedy is faster',
            'Greedy makes locally optimal choices; DP solves overlapping subproblems',
            'DP is simpler',
            'Both are the same'
        ],
        correctAnswer: 'Greedy makes locally optimal choices; DP solves overlapping subproblems',
        explanation: 'Greedy algorithms make locally optimal choices hoping to find global optimum. Dynamic programming solves overlapping subproblems using memoization or tabulation.'
    },
    {
        id: 106,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'What is the time complexity of quick sort in the best case?',
        options: [
            'O(n)',
            'O(n log n)',
            'O(n²)',
            'O(log n)'
        ],
        correctAnswer: 'O(n log n)',
        explanation: 'Quick sort has O(n log n) average and best case complexity (when partitions are balanced). Worst case is O(n²) when pivot selection is poor.'
    },
    {
        id: 107,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'Which algorithm is used to find shortest path in a graph?',
        options: [
            'Bubble Sort',
            'Merge Sort',
            'Dijkstra\'s Algorithm',
            'Quick Sort'
        ],
        correctAnswer: 'Dijkstra\'s Algorithm',
        explanation: 'Dijkstra\'s algorithm finds the shortest path from a source to all other vertices in a weighted graph. It uses a greedy approach.'
    },
    {
        id: 108,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'advanced',
        question: 'What is memoization in dynamic programming?',
        options: [
            'Writing notes',
            'Storing previously computed results to avoid recomputation',
            'A sorting technique',
            'A type of linked list'
        ],
        correctAnswer: 'Storing previously computed results to avoid recomputation',
        explanation: 'Memoization is a technique to cache (store) results of expensive function calls and return the cached result when the same inputs occur again.'
    },
    {
        id: 109,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'advanced',
        question: 'What is the space complexity of merge sort?',
        options: [
            'O(1)',
            'O(log n)',
            'O(n)',
            'O(n²)'
        ],
        correctAnswer: 'O(n)',
        explanation: 'Merge sort requires O(n) extra space for the temporary arrays used during merging, making it less space-efficient than quick sort which uses O(log n).'
    },
    {
        id: 110,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'advanced',
        question: 'What is backtracking?',
        options: [
            'Reversing an array',
            'Solving a problem by trying different paths and abandoning those that fail',
            'A sorting technique',
            'Accessing previous elements in a list'
        ],
        correctAnswer: 'Solving a problem by trying different paths and abandoning those that fail',
        explanation: 'Backtracking is a problem-solving technique that considers searching every possible combination in a discrete space by exploring partial solutions and abandoning them when they fail to satisfy constraints.'
    },

    // Normal Q&A - Algorithms
    {
        id: 111,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'beginner',
        question: 'Explain the concept of time complexity and why it matters.',
        expectedKeywords: ['time complexity', 'Big O', 'performance', 'efficiency', 'input size', 'worst case', 'operations'],
        explanation: 'Time complexity describes how the runtime of an algorithm grows with input size using Big O notation. It\'s crucial for understanding algorithm efficiency and scalability.'
    },
    {
        id: 112,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'beginner',
        question: 'What is space complexity? Give examples.',
        expectedKeywords: ['space complexity', 'memory', 'auxiliary space', 'O(1)', 'O(n)', 'Big O', 'storage'],
        explanation: 'Space complexity measures memory used by an algorithm relative to input size. O(1) uses constant space, O(n) uses linear space proportional to input size.'
    },
    {
        id: 113,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'Explain the divide-and-conquer approach in algorithms.',
        expectedKeywords: ['divide-and-conquer', 'divide', 'conquer', 'combine', 'merge sort', 'quick sort', 'breaking down'],
        explanation: 'Divide-and-conquer breaks a problem into smaller subproblems, solves them independently, and combines the results. Examples: merge sort, quick sort, binary search.'
    },
    {
        id: 114,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'What are the characteristics of a greedy algorithm?',
        expectedKeywords: ['greedy', 'locally optimal', 'global optimum', 'choice', 'stage', 'heuristic', 'approximation'],
        explanation: 'Greedy algorithms make locally optimal choices at each step, hoping to find a global optimum. They\'re fast but don\'t always guarantee optimal solutions.'
    },
    {
        id: 115,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'Explain the concept of recursion in algorithms.',
        expectedKeywords: ['recursion', 'base case', 'recursive case', 'call stack', 'termination', 'function calling itself'],
        explanation: 'Recursion is when a function calls itself to solve smaller instances of the same problem. Must have a base case to terminate. Used in many algorithms like factorial, fibonacci.'
    },
    {
        id: 116,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'advanced',
        question: 'Explain dynamic programming and provide an example.',
        expectedKeywords: ['dynamic programming', 'overlapping subproblems', 'optimal substructure', 'memoization', 'fibonacci', 'coin change'],
        explanation: 'DP solves problems with overlapping subproblems and optimal substructure by storing results. Example: Fibonacci sequence F(n) = F(n-1) + F(n-2) avoids recalculating same values.'
    },
    {
        id: 117,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'advanced',
        question: 'What is BFS and DFS? Explain their differences and use cases.',
        expectedKeywords: ['BFS', 'DFS', 'breadth-first', 'depth-first', 'queue', 'stack', 'shortest path', 'connected components'],
        explanation: 'BFS explores level by level using a queue; useful for shortest paths. DFS explores deeply using a stack; useful for topological sort and connected components.'
    },
    {
        id: 118,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'advanced',
        question: 'Explain the concept of NP-completeness.',
        expectedKeywords: ['NP-complete', 'NP', 'P', 'NP-hard', 'verification', 'polynomial time', 'satisfiability', 'traveling salesman'],
        explanation: 'P problems are solvable in polynomial time. NP problems are verifiable in polynomial time. NP-complete problems are NP and as hard as any NP problem. Example: Traveling Salesman Problem.'
    },
    {
        id: 119,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'What is the difference between a stable and unstable sorting algorithm?',
        expectedKeywords: ['stable sort', 'unstable sort', 'equal elements', 'order preserved', 'merge sort', 'quick sort'],
        explanation: 'Stable sort preserves the relative order of equal elements. Merge sort is stable; quick sort is not. This matters when sorting objects with multiple attributes.'
    },
    {
        id: 120,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'Explain the concept of Big O notation and provide examples.',
        expectedKeywords: ['Big O', 'O(1)', 'O(log n)', 'O(n)', 'O(n²)', 'constant', 'linear', 'quadratic', 'logarithmic'],
        explanation: 'Big O measures algorithm efficiency. O(1) is constant, O(log n) is logarithmic, O(n) is linear, O(n²) is quadratic. Used to compare algorithm performance.'
    },

    // ==================== DATABASE MANAGEMENT SYSTEMS (50+ questions) ====================

    // MCQs - DBMS
    {
        id: 201,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'beginner',
        question: 'What is a database?',
        options: [
            'An organized collection of structured data',
            'A programming language',
            'A type of algorithm',
            'A web framework'
        ],
        correctAnswer: 'An organized collection of structured data',
        explanation: 'A database is an organized collection of structured data stored in a computer system for easy access, retrieval, and modification.'
    },
    {
        id: 202,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'beginner',
        question: 'What is a primary key?',
        options: [
            'The first column in a table',
            'A unique identifier for each record in a table',
            'The column with the most important data',
            'A backup key'
        ],
        correctAnswer: 'A unique identifier for each record in a table',
        explanation: 'A primary key uniquely identifies each record in a table. No two records can have the same primary key value.'
    },
    {
        id: 203,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'beginner',
        question: 'What is normalization in databases?',
        options: [
            'Making all data the same size',
            'Process of organizing data to reduce redundancy',
            'Sorting data alphabetically',
            'Encrypting data'
        ],
        correctAnswer: 'Process of organizing data to reduce redundancy',
        explanation: 'Normalization is a process of organizing data in a database to eliminate redundancy and ensure data integrity through various normal forms (1NF, 2NF, 3NF, etc.).'
    },
    {
        id: 204,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'What is the difference between a foreign key and a primary key?',
        options: [
            'They are the same thing',
            'Primary key identifies records; foreign key links tables',
            'Foreign key identifies records; primary key links tables',
            'There is no difference'
        ],
        correctAnswer: 'Primary key identifies records; foreign key links tables',
        explanation: 'Primary key uniquely identifies records in a table. Foreign key links records in one table to records in another table, enforcing referential integrity.'
    },
    {
        id: 205,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'What are ACID properties?',
        options: [
            'Attributes, Columns, Index, Database',
            'Atomicity, Consistency, Isolation, Durability',
            'Application, Coding, Integration, Design',
            'Asymmetric, Complexity, Integer, Digital'
        ],
        correctAnswer: 'Atomicity, Consistency, Isolation, Durability',
        explanation: 'ACID properties ensure reliable database transactions: Atomicity (all or nothing), Consistency (valid state), Isolation (concurrent independence), Durability (permanent).'
    },
    {
        id: 206,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'What is the difference between INNER JOIN and OUTER JOIN?',
        options: [
            'INNER JOIN is faster',
            'INNER JOIN returns matching records; OUTER JOIN includes non-matching',
            'OUTER JOIN returns matching records; INNER JOIN includes non-matching',
            'There is no difference'
        ],
        correctAnswer: 'INNER JOIN returns matching records; OUTER JOIN includes non-matching',
        explanation: 'INNER JOIN returns only matching records from both tables. OUTER JOIN (LEFT/RIGHT/FULL) includes non-matching records filled with NULL values.'
    },
    {
        id: 207,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'advanced',
        question: 'What is a transaction in database?',
        options: [
            'A single SQL query',
            'A sequence of database operations treated as a single unit',
            'Transferring data between tables',
            'Backing up a database'
        ],
        correctAnswer: 'A sequence of database operations treated as a single unit',
        explanation: 'A transaction is a sequence of one or more SQL statements executed as a single atomic unit. Either all operations complete successfully or none do.'
    },
    {
        id: 208,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'advanced',
        question: 'What is indexing in databases?',
        options: [
            'Sorting data',
            'Creating a sorted data structure for faster data retrieval',
            'Numbering rows',
            'Grouping data'
        ],
        correctAnswer: 'Creating a sorted data structure for faster data retrieval',
        explanation: 'Indexing creates a separate structure (usually B-tree) that maps values to their row locations, enabling faster searches at the cost of additional storage and slower writes.'
    },
    {
        id: 209,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'advanced',
        question: 'What is denormalization?',
        options: [
            'Fixing an incorrectly normalized database',
            'Intentionally introducing redundancy for performance',
            'Removing all redundancy',
            'Adding more tables'
        ],
        correctAnswer: 'Intentionally introducing redundancy for performance',
        explanation: 'Denormalization is the process of intentionally duplicating data to improve read performance at the expense of write performance and storage space.'
    },
    {
        id: 210,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'advanced',
        question: 'What is the difference between SQL and NoSQL?',
        options: [
            'SQL is faster',
            'SQL is relational; NoSQL is non-relational document/key-value',
            'NoSQL is more secure',
            'They are the same'
        ],
        correctAnswer: 'SQL is relational; NoSQL is non-relational document/key-value',
        explanation: 'SQL databases are relational with structured schemas. NoSQL databases (MongoDB, Cassandra) are non-relational, flexible, and designed for large-scale distributed systems.'
    },

    // Normal Q&A - DBMS
    {
        id: 211,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'beginner',
        question: 'What is the difference between a row and a column in a database table?',
        expectedKeywords: ['row', 'column', 'record', 'field', 'attribute', 'horizontal', 'vertical', 'data'],
        explanation: 'A row (record) is a horizontal collection of data representing one entity. A column (field/attribute) is a vertical collection representing one property of all entities.'
    },
    {
        id: 212,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'beginner',
        question: 'Explain the concept of relationships in databases.',
        expectedKeywords: ['relationships', 'one-to-one', 'one-to-many', 'many-to-many', 'foreign key', 'association', 'cardinality'],
        explanation: 'Relationships define how tables relate to each other. One-to-one: one record relates to one record. One-to-many: one record relates to multiple records. Many-to-many: many records relate to many records.'
    },
    {
        id: 213,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'Explain the first three normal forms in database normalization.',
        expectedKeywords: ['1NF', '2NF', '3NF', 'atomic', 'partial dependency', 'transitive dependency', 'candidate key'],
        explanation: '1NF: All attributes are atomic. 2NF: In 1NF and no partial dependencies. 3NF: In 2NF and no transitive dependencies. Each eliminates different types of redundancy.'
    },
    {
        id: 214,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'What is an Entity-Relationship (ER) model? Explain its components.',
        expectedKeywords: ['ER model', 'entity', 'attribute', 'relationship', 'cardinality', 'diagram', 'mapping', 'entities'],
        explanation: 'ER model represents data as entities, attributes, and relationships. Entities are objects, attributes are properties, relationships show associations. Used for database design before implementation.'
    },
    {
        id: 215,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'Explain the concept of constraints in databases.',
        expectedKeywords: ['constraints', 'PRIMARY KEY', 'FOREIGN KEY', 'UNIQUE', 'NOT NULL', 'CHECK', 'integrity', 'validation'],
        explanation: 'Constraints enforce data integrity: PRIMARY KEY (unique), FOREIGN KEY (referential integrity), UNIQUE (no duplicates), NOT NULL (required), CHECK (custom validation).'
    },
    {
        id: 216,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'advanced',
        question: 'Explain the difference between structured and unstructured data.',
        expectedKeywords: ['structured', 'unstructured', 'schema', 'relational', 'format', 'SQL', 'NoSQL', 'flexible'],
        explanation: 'Structured data has a fixed schema (SQL). Unstructured data has no predefined format (images, videos, text). Semi-structured data has some organization (JSON, XML).'
    },
    {
        id: 217,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'advanced',
        question: 'What are views in databases? What are their advantages?',
        expectedKeywords: ['views', 'virtual table', 'SELECT query', 'security', 'simplicity', 'abstraction', 'read-only'],
        explanation: 'Views are virtual tables created from one or more base tables using SELECT queries. Advantages: security (restrict column access), simplicity, data abstraction.'
    },
    {
        id: 218,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'advanced',
        question: 'Explain the concept of database locking and deadlock.',
        expectedKeywords: ['locking', 'deadlock', 'concurrency', 'mutual exclusion', 'circular wait', 'resource', 'timeout', 'prevention'],
        explanation: 'Locking prevents concurrent access conflicts. Deadlock occurs when two transactions wait for each other\'s locks. Prevention: lock ordering, timeouts, cycle detection.'
    },
    {
        id: 219,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'What is the difference between a superkey and a candidate key?',
        expectedKeywords: ['superkey', 'candidate key', 'minimal', 'unique', 'identifier', 'primary key', 'attributes'],
        explanation: 'Superkey: any set of attributes that uniquely identifies records. Candidate key: minimal superkey with no redundant attributes. Primary key is selected from candidate keys.'
    },
    {
        id: 220,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'Explain aggregation functions in SQL with examples.',
        expectedKeywords: ['aggregation', 'COUNT', 'SUM', 'AVG', 'MIN', 'MAX', 'GROUP BY', 'statistics'],
        explanation: 'Aggregation functions perform calculations on groups of rows: COUNT (number), SUM (total), AVG (average), MIN/MAX (minimum/maximum). Used with GROUP BY for grouping.'
    },

    // ==================== PYTHON (Beginner Level - Bonus) ====================
    {
        id: 301,
        type: 'mcq',
        category: 'Python',
        difficulty: 'beginner',
        question: 'What is Python?',
        options: [
            'A type of snake',
            'A high-level, interpreted programming language',
            'A database system',
            'An operating system'
        ],
        correctAnswer: 'A high-level, interpreted programming language',
        explanation: 'Python is a high-level, interpreted, dynamically-typed programming language known for its simplicity and readability.'
    },
    {
        id: 302,
        type: 'mcq',
        category: 'Python',
        difficulty: 'beginner',
        question: 'What is the correct syntax to print output in Python?',
        options: [
            'echo "Hello"',
            'print("Hello")',
            'printf("Hello")',
            'console.log("Hello")'
        ],
        correctAnswer: 'print("Hello")',
        explanation: 'In Python, print() is the built-in function used to output text to the console.'
    },
    {
        id: 303,
        type: 'mcq',
        category: 'Python',
        difficulty: 'beginner',
        question: 'Which data type is used to store multiple items in Python?',
        options: [
            'String',
            'Integer',
            'List',
            'Boolean'
        ],
        correctAnswer: 'List',
        explanation: 'Lists are used to store multiple items in Python. They are ordered, mutable, and allow duplicates. Defined with square brackets [].'
    }
];

module.exports = comprehensiveQuestions;
