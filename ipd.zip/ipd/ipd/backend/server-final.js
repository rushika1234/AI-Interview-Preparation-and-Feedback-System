const express = require('express');
const app = express();
const port = 3000;
const { Question } = require('./database');
const bTechQuestions = require('./bTechQuestions');

// Middleware to parse JSON
app.use(express.json());

// Route: Home
app.get('/', (req, res) => {
    res.send('Welcome to AI Interview Preparation System - B.Tech Software Engineering');
});

// Route: Add all B.Tech questions to database
app.post('/add-all-questions', async (req, res) => {
    try {
        // Clear existing questions
        await Question.deleteMany({});
        
        // Insert new questions
        await Question.insertMany(bTechQuestions);
        res.json({
            message: `Successfully added ${bTechQuestions.length} B.Tech interview questions!`,
            totalQuestions: bTechQuestions.length,
            categories: {
                'Data Structures': 60,
                'Algorithms': 60,
                'DBMS': 60,
                'Operating Systems': 60,
                'Computer Networks': 60,
                'Web Development': 50,
                'Software Engineering': 50
            }
        });
    } catch (error) {
        console.error('Error adding questions:', error);
        res.status(500).json({ message: 'Failed to add questions.' });
    }
});

// Route: Get all categories
app.get('/categories', async (req, res) => {
    try {
        const categories = [
            'Data Structures',
            'Algorithms',
            'DBMS',
            'Operating Systems',
            'Computer Networks',
            'Web Development',
            'Software Engineering'
        ];
        res.json({ categories: categories });
    } catch (error) {
        console.error('Error fetching categories:', error);
        res.status(500).json({ message: 'Failed to fetch categories.' });
    }
});

// Route: Get questions by category
app.get('/questions/category/:category', async (req, res) => {
    try {
        const { category } = req.params;
        const questions = await Question.find({ category: category });
        res.json({
            category: category,
            totalQuestions: questions.length,
            questions: questions
        });
    } catch (error) {
        console.error('Error fetching questions:', error);
        res.status(500).json({ message: 'Failed to fetch questions.' });
    }
});

// Route: Get questions by difficulty level
app.get('/questions/difficulty/:difficulty', async (req, res) => {
    try {
        const { difficulty } = req.params;
        const questions = await Question.find({ difficulty: difficulty });
        res.json({
            difficulty: difficulty,
            totalQuestions: questions.length,
            questions: questions
        });
    } catch (error) {
        console.error('Error fetching questions:', error);
        res.status(500).json({ message: 'Failed to fetch questions.' });
    }
});

// Route: Get random questions for mock interview
app.get('/questions/random/:count', async (req, res) => {
    try {
        const { count } = req.params;
        const questions = await Question.aggregate([{ $sample: { size: parseInt(count) } }]);
        res.json({
            totalQuestions: questions.length,
            questions: questions
        });
    } catch (error) {
        console.error('Error fetching random questions:', error);
        res.status(500).json({ message: 'Failed to fetch random questions.' });
    }
});

// Route: Get random questions by category
app.get('/questions/random/:category/:count', async (req, res) => {
    try {
        const { category, count } = req.params;
        const questions = await Question.aggregate([
            { $match: { category: category } },
            { $sample: { size: parseInt(count) } }
        ]);
        res.json({
            category: category,
            totalQuestions: questions.length,
            questions: questions
        });
    } catch (error) {
        console.error('Error fetching random questions:', error);
        res.status(500).json({ message: 'Failed to fetch random questions.' });
    }
});

// Route: Get all questions
app.get('/questions/all', async (req, res) => {
    try {
        const questions = await Question.find({});
        res.json({
            totalQuestions: questions.length,
            questions: questions
        });
    } catch (error) {
        console.error('Error fetching questions:', error);
        res.status(500).json({ message: 'Failed to fetch questions.' });
    }
});

// Route: Conduct mock interview
app.post('/mock-interview', (req, res) => {
    const { username, questions } = req.body;

    const responses = questions.map((question, index) => ({
        question: question,
        response: `Sample response for question ${index + 1}`
    }));

    res.json({
        message: `Mock interview conducted for ${username}`,
        totalQuestions: questions.length,
        responses: responses
    });
});

// Route: Provide feedback
app.post('/feedback', async (req, res) => {
    const { username, responses } = req.body;

    // AI-based feedback generation (can be enhanced with actual AI)
    const feedback = responses.map((response, index) => ({
        question: response.question,
        userResponse: response.response,
        feedback: `Comprehensive feedback for response ${index + 1}`,
        score: Math.floor(Math.random() * 100) + 1,
        suggestions: [
            'Focus on clarity and conciseness',
            'Provide relevant examples',
            'Structure your answer logically'
        ]
    }));

    res.json({
        message: `Feedback generated for ${username}`,
        totalResponses: responses.length,
        feedback: feedback,
        overallScore: Math.floor(feedback.reduce((sum, f) => sum + f.score, 0) / feedback.length)
    });
});

// Route: Get interview statistics
app.get('/interview/stats/:username', (req, res) => {
    const { username } = req.params;
    res.json({
        username: username,
        interviewsCompleted: 5,
        averageScore: 75,
        categoriesAttempted: ['Data Structures', 'Algorithms', 'DBMS'],
        lastInterviewDate: '2024-01-20'
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
    console.log(`
    ====================================
    AI Interview Preparation System
    ====================================
    
    Available Endpoints:
    
    GET  /                              - Home
    POST /add-all-questions             - Load all B.Tech questions
    GET  /categories                    - Get all categories
    GET  /questions/all                 - Get all questions
    GET  /questions/category/:category  - Get by category
    GET  /questions/difficulty/:level   - Get by difficulty
    GET  /questions/random/:count       - Get random questions
    GET  /questions/random/:cat/:count  - Get random from category
    POST /mock-interview                - Conduct mock interview
    POST /feedback                      - Generate feedback
    GET  /interview/stats/:username     - Get interview statistics
    
    ====================================
    `);
});
