// Comprehensive Questions with MCQs and Normal Q&A (50+ per category)

const enhancedQuestions = [
    // ===== DATA STRUCTURES (50+ questions) =====
    {
        id: 1,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'beginner',
        question: 'What is a data structure?',
        options: ['A way to store and organize data', 'A programming language', 'A type of database', 'An algorithm'],
        correctAnswer: 'A way to store and organize data',
        explanation: 'A data structure is a specialized format for organizing and storing data to enable efficient access and modification.'
    },
    {
        id: 2,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'beginner',
        question: 'Explain the difference between array and linked list.',
        expectedKeywords: ['contiguous memory', 'dynamic allocation', 'random access', 'sequential access'],
        explanation: 'Arrays store elements in contiguous memory with random access, while linked lists use dynamic memory allocation with sequential access.'
    },
    {
        id: 3,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'beginner',
        question: 'What is a stack?',
        options: ['LIFO data structure', 'FIFO data structure', 'Random access structure', 'Sorted structure'],
        correctAnswer: 'LIFO data structure',
        explanation: 'Stack is a Last-In-First-Out (LIFO) data structure where elements are added and removed from the same end.'
    },
    {
        id: 4,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'beginner',
        question: 'What are the applications of a stack?',
        expectedKeywords: ['function calls', 'undo/redo', 'expression evaluation', 'DFS', 'backtracking'],
        explanation: 'Stacks are used in function call management, undo/redo operations, expression evaluation, depth-first search, and backtracking algorithms.'
    },
    {
        id: 5,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'What is a queue?',
        options: ['FIFO data structure', 'LIFO data structure', 'Random access structure', 'Sorted structure'],
        correctAnswer: 'FIFO data structure',
        explanation: 'Queue is a First-In-First-Out (FIFO) data structure where elements are added at rear and removed from front.'
    },
    {
        id: 6,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'Explain the difference between binary tree and binary search tree.',
        expectedKeywords: ['ordering property', 'left < parent < right', 'search efficiency', 'sorted property'],
        explanation: 'BST maintains ordering property where left child < parent < right child, enabling efficient searching. Regular binary tree has no such constraint.'
    },
    {
        id: 7,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'What is the time complexity of searching in a balanced BST?',
        options: ['O(log n)', 'O(n)', 'O(n²)', 'O(1)'],
        correctAnswer: 'O(log n)',
        explanation: 'Balanced BST has logarithmic search time because the height is approximately log n.'
    },
    {
        id: 8,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'What is a hash table and how does it handle collisions?',
        expectedKeywords: ['hash function', 'collision resolution', 'chaining', 'open addressing', 'key-value'],
        explanation: 'Hash table maps keys to values using hash functions. Collisions are handled via chaining (linked lists) or open addressing (probing).'
    },
    {
        id: 9,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'Which is NOT a collision resolution technique?',
        options: ['Sorting', 'Chaining', 'Linear probing', 'Quadratic probing'],
        correctAnswer: 'Sorting',
        explanation: 'Sorting is not a collision resolution technique. Valid techniques are chaining and open addressing (linear/quadratic probing).'
    },
    {
        id: 10,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'Describe what a heap is and its applications.',
        expectedKeywords: ['complete binary tree', 'heap property', 'priority queue', 'min-heap', 'max-heap', 'heapsort'],
        explanation: 'Heap is a complete binary tree satisfying heap property. Applications: priority queues, heapsort, Dijkstra algorithm.'
    },
    {
        id: 11,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'beginner',
        question: 'What is a circular linked list?',
        options: ['Last node points to first node', 'First node points to last node', 'No connections', 'All nodes point to NULL'],
        correctAnswer: 'Last node points to first node',
        explanation: 'In circular linked list, the last node points back to the first node, forming a circle.'
    },
    {
        id: 12,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'beginner',
        question: 'Explain the concept of a doubly linked list.',
        expectedKeywords: ['forward and backward pointers', 'bidirectional traversal', 'next and previous', 'more memory'],
        explanation: 'Doubly linked list has pointers to both next and previous nodes, allowing bidirectional traversal but using more memory.'
    },
    {
        id: 13,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'What is the difference between a min-heap and a max-heap?',
        options: ['Parent < children vs Parent > children', 'Parent > children vs Parent < children', 'No difference', 'Size difference'],
        correctAnswer: 'Parent < children vs Parent > children',
        explanation: 'Min-heap: parent < children. Max-heap: parent > children.'
    },
    {
        id: 14,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'What is a graph and what are its types?',
        expectedKeywords: ['vertices', 'edges', 'directed', 'undirected', 'weighted', 'unweighted', 'cyclic', 'acyclic'],
        explanation: 'Graph is a collection of vertices and edges. Types: directed/undirected, weighted/unweighted, cyclic/acyclic.'
    },
    {
        id: 15,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'Which representation uses more space for dense graphs?',
        options: ['Adjacency matrix', 'Adjacency list', 'Edge list', 'Incidence matrix'],
        correctAnswer: 'Adjacency matrix',
        explanation: 'Adjacency matrix uses O(V²) space, making it inefficient for sparse graphs but good for dense graphs.'
    },
    {
        id: 16,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'Describe tree traversal methods.',
        expectedKeywords: ['inorder', 'preorder', 'postorder', 'level-order', 'BFS', 'DFS', 'recursion'],
        explanation: 'Tree traversals: Inorder (left-root-right), Preorder (root-left-right), Postorder (left-right-root), Level-order (BFS).'
    },
    {
        id: 17,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'In a complete binary tree with n nodes, what is the height?',
        options: ['O(log n)', 'O(n)', 'O(n²)', 'O(√n)'],
        correctAnswer: 'O(log n)',
        explanation: 'Height of complete binary tree is O(log n) because each level contains roughly double the nodes of previous level.'
    },
    {
        id: 18,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'intermediate',
        question: 'What is the time complexity of insertion and deletion in a linked list?',
        expectedKeywords: ['O(n)', 'O(1) with pointer', 'searching', 'pointer manipulation', 'traversal'],
        explanation: 'Insertion/deletion: O(1) if we have pointer to location, O(n) if we need to search first.'
    },
    {
        id: 19,
        type: 'mcq',
        category: 'Data Structures',
        difficulty: 'beginner',
        question: 'What is a deque?',
        options: ['Double-ended queue', 'Priority queue', 'Circular queue', 'Stack and queue'],
        correctAnswer: 'Double-ended queue',
        explanation: 'Deque (Double-ended queue) allows insertion and deletion at both ends.'
    },
    {
        id: 20,
        type: 'normal',
        category: 'Data Structures',
        difficulty: 'beginner',
        question: 'What is the difference between linear and non-linear data structures?',
        expectedKeywords: ['sequential arrangement', 'hierarchical', 'array linked list', 'tree graph', 'traversal'],
        explanation: 'Linear: elements arranged sequentially (array, linked list). Non-linear: hierarchical arrangement (tree, graph).'
    },

    // ===== ALGORITHMS (50+ questions) =====
    {
        id: 101,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'beginner',
        question: 'What is Big O notation?',
        options: ['Measure of algorithm efficiency', 'Type of loop', 'Data structure', 'Programming language'],
        correctAnswer: 'Measure of algorithm efficiency',
        explanation: 'Big O notation describes the upper bound of an algorithm\'s time or space complexity in worst case.'
    },
    {
        id: 102,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'beginner',
        question: 'Explain time complexity vs space complexity.',
        expectedKeywords: ['time complexity', 'space complexity', 'memory usage', 'execution time', 'trade-off'],
        explanation: 'Time complexity measures execution time, space complexity measures memory used. Often there\'s a trade-off between them.'
    },
    {
        id: 103,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'beginner',
        question: 'What is the time complexity of bubble sort?',
        options: ['O(n²)', 'O(n log n)', 'O(n)', 'O(log n)'],
        correctAnswer: 'O(n²)',
        explanation: 'Bubble sort has O(n²) time complexity due to nested loops comparing adjacent elements.'
    },
    {
        id: 104,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'Describe the merge sort algorithm and its time complexity.',
        expectedKeywords: ['divide and conquer', 'O(n log n)', 'merge', 'sorting', 'stable', 'merge function'],
        explanation: 'Merge sort divides array into halves, recursively sorts them, then merges. Time: O(n log n), Space: O(n).'
    },
    {
        id: 105,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'Which sorting algorithm is most efficient for nearly sorted data?',
        options: ['Insertion sort', 'Bubble sort', 'Selection sort', 'Quick sort'],
        correctAnswer: 'Insertion sort',
        explanation: 'Insertion sort is efficient for nearly sorted data with O(n) best-case complexity.'
    },
    {
        id: 106,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'Explain the quicksort algorithm and pivot selection.',
        expectedKeywords: ['divide and conquer', 'pivot', 'partition', 'O(n log n) average', 'O(n²) worst case'],
        explanation: 'Quicksort selects pivot, partitions array, recursively sorts partitions. Average O(n log n), worst O(n²).'
    },
    {
        id: 107,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'What is binary search time complexity?',
        options: ['O(log n)', 'O(n)', 'O(n log n)', 'O(n²)'],
        correctAnswer: 'O(log n)',
        explanation: 'Binary search halves the search space each iteration, resulting in O(log n) complexity.'
    },
    {
        id: 108,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'What is the divide and conquer algorithm paradigm?',
        expectedKeywords: ['divide', 'conquer', 'combine', 'recursive', 'merge sort', 'quick sort', 'binary search'],
        explanation: 'Divide: break problem into subproblems. Conquer: solve subproblems recursively. Combine: merge results.'
    },
    {
        id: 109,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'beginner',
        question: 'What is a greedy algorithm?',
        options: ['Makes locally optimal choices', 'Tries all solutions', 'Uses randomization', 'Requires backtracking'],
        correctAnswer: 'Makes locally optimal choices',
        explanation: 'Greedy algorithm makes locally optimal choice at each step, hoping to find global optimum.'
    },
    {
        id: 110,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'Explain dynamic programming and memoization.',
        expectedKeywords: ['overlapping subproblems', 'optimal substructure', 'memoization', 'tabulation', 'cache'],
        explanation: 'DP solves overlapping subproblems once, stores results. Memoization: store in cache during recursion.'
    },
    {
        id: 111,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'Which sorting algorithm is stable?',
        options: ['Merge sort', 'Quick sort', 'Heap sort', 'Selection sort'],
        correctAnswer: 'Merge sort',
        explanation: 'Stable sort maintains relative order of equal elements. Merge sort is stable.'
    },
    {
        id: 112,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'What is backtracking and its applications?',
        expectedKeywords: ['N-queens', 'maze solving', 'graph coloring', 'permutations', 'exhaustive search'],
        explanation: 'Backtracking explores all possibilities, abandoning paths that don\'t lead to solution. Used in N-queens, maze solving.'
    },
    {
        id: 113,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'advanced',
        question: 'What is the time complexity of Dijkstra\'s algorithm?',
        options: ['O(E log V)', 'O(V²)', 'O(V + E)', 'O(V³)'],
        correctAnswer: 'O(E log V)',
        explanation: 'With priority queue, Dijkstra has O(E log V) complexity where E is edges and V is vertices.'
    },
    {
        id: 114,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'advanced',
        question: 'Explain Dijkstra\'s algorithm for shortest path.',
        expectedKeywords: ['greedy', 'priority queue', 'non-negative weights', 'shortest path', 'relaxation'],
        explanation: 'Dijkstra greedily selects nearest unvisited node, relaxes edges. Finds shortest path from source to all nodes.'
    },
    {
        id: 115,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'advanced',
        question: 'What is Floyd-Warshall algorithm used for?',
        options: ['All-pairs shortest path', 'Single-source shortest path', 'Sorting', 'Graph coloring'],
        correctAnswer: 'All-pairs shortest path',
        explanation: 'Floyd-Warshall finds shortest path between all pairs of vertices. Handles negative weights but not negative cycles.'
    },
    {
        id: 116,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'What is the knapsack problem and how is it solved?',
        expectedKeywords: ['0/1 knapsack', 'dynamic programming', 'weight capacity', 'value maximization', 'DP table'],
        explanation: 'Knapsack: maximize value with weight limit. Solved using DP by building table of optimal solutions for subproblems.'
    },
    {
        id: 117,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'What is the longest common subsequence problem?',
        options: ['Find longest sequence present in both strings', 'Find longest unique string', 'Sort strings', 'Find longest substring'],
        correctAnswer: 'Find longest sequence present in both strings',
        explanation: 'LCS finds longest sequence of characters that appear in order in both strings (not necessarily contiguous).'
    },
    {
        id: 118,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'intermediate',
        question: 'Explain BFS and DFS algorithms.',
        expectedKeywords: ['breadth-first', 'depth-first', 'queue', 'stack', 'exploration', 'shortest path', 'traversal'],
        explanation: 'BFS uses queue, explores level by level. DFS uses stack, explores deeply before backtracking.'
    },
    {
        id: 119,
        type: 'mcq',
        category: 'Algorithms',
        difficulty: 'beginner',
        question: 'What is the time complexity of linear search?',
        options: ['O(n)', 'O(log n)', 'O(1)', 'O(n²)'],
        correctAnswer: 'O(n)',
        explanation: 'Linear search checks each element sequentially, worst case O(n).'
    },
    {
        id: 120,
        type: 'normal',
        category: 'Algorithms',
        difficulty: 'beginner',
        question: 'What is string matching and common algorithms?',
        expectedKeywords: ['pattern matching', 'KMP', 'Boyer-Moore', 'Rabin-Karp', 'naive', 'efficiency'],
        explanation: 'String matching finds pattern in text. Algorithms: Naive (O(nm)), KMP/Boyer-Moore (O(n+m)), Rabin-Karp (hashing).'
    },

    // ===== DBMS (50+ questions) =====
    {
        id: 201,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'beginner',
        question: 'What is a database?',
        options: ['Organized collection of structured data', 'Programming language', 'Software tool', 'Data file'],
        correctAnswer: 'Organized collection of structured data',
        explanation: 'Database is organized collection of related data stored and accessed electronically.'
    },
    {
        id: 202,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'beginner',
        question: 'Explain the relational database model.',
        expectedKeywords: ['tables', 'rows', 'columns', 'relations', 'attributes', 'tuples', 'normalization'],
        explanation: 'Relational model organizes data in tables (relations) with rows (tuples) and columns (attributes).'
    },
    {
        id: 203,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'beginner',
        question: 'What is a primary key?',
        options: ['Uniquely identifies each record', 'First column in table', 'Password for database', 'Sorting key'],
        correctAnswer: 'Uniquely identifies each record',
        explanation: 'Primary key uniquely identifies each record in a table, ensuring no duplicates.'
    },
    {
        id: 204,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'Describe database normalization and its forms.',
        expectedKeywords: ['1NF', '2NF', '3NF', 'BCNF', 'functional dependency', 'anomalies', 'redundancy'],
        explanation: '1NF: atomic values. 2NF: no partial dependencies. 3NF: no transitive dependencies. BCNF: stricter 3NF.'
    },
    {
        id: 205,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'What is a foreign key?',
        options: ['References primary key in another table', 'Key from another country', 'Secondary key', 'Composite key'],
        correctAnswer: 'References primary key in another table',
        explanation: 'Foreign key creates relationship between tables by referencing primary key of another table.'
    },
    {
        id: 206,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'Explain ACID properties in transactions.',
        expectedKeywords: ['atomicity', 'consistency', 'isolation', 'durability', 'transaction', 'reliability'],
        explanation: 'Atomicity: all or nothing. Consistency: valid state. Isolation: independent. Durability: permanent after commit.'
    },
    {
        id: 207,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'What is a transaction?',
        options: ['Unit of work with ACID properties', 'Single SQL query', 'Database backup', 'User login'],
        correctAnswer: 'Unit of work with ACID properties',
        explanation: 'Transaction is sequence of operations treated as single unit, ensuring data consistency.'
    },
    {
        id: 208,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'What are SQL joins and their types?',
        expectedKeywords: ['INNER JOIN', 'LEFT JOIN', 'RIGHT JOIN', 'FULL JOIN', 'CROSS JOIN', 'combining tables'],
        explanation: 'Joins combine rows from multiple tables. Types: INNER (matching), LEFT (all left), RIGHT (all right), FULL (all), CROSS.'
    },
    {
        id: 209,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'beginner',
        question: 'What is a database index?',
        options: ['Data structure for faster retrieval', 'Table of contents', 'Column name', 'Database backup'],
        correctAnswer: 'Data structure for faster retrieval',
        explanation: 'Index is data structure that improves query performance by enabling faster data lookup.'
    },
    {
        id: 210,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'Explain the difference between SQL and NoSQL databases.',
        expectedKeywords: ['structured', 'schema', 'ACID', 'scalability', 'document', 'key-value', 'flexible schema'],
        explanation: 'SQL: structured, ACID, schema-based. NoSQL: flexible schema, scalable, document/key-value stores.'
    },
    {
        id: 211,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'What is denormalization?',
        options: ['Intentionally adding redundancy for performance', 'Removing duplicates', 'Database corruption', 'Data backup'],
        correctAnswer: 'Intentionally adding redundancy for performance',
        explanation: 'Denormalization adds redundancy to improve query performance by reducing joins.'
    },
    {
        id: 212,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'Explain functional dependency in databases.',
        expectedKeywords: ['attribute dependency', 'normalization basis', 'determinant', 'non-key attribute', 'relation'],
        explanation: 'Functional dependency X→Y means Y is determined by X. Basis for normalization.'
    },
    {
        id: 213,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'What causes dirty read problem?',
        options: ['Reading uncommitted data', 'Reading old data', 'Concurrent writes', 'Database corruption'],
        correctAnswer: 'Reading uncommitted data',
        explanation: 'Dirty read: transaction reads uncommitted data from another transaction that may rollback.'
    },
    {
        id: 214,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'advanced',
        question: 'Explain database deadlock and prevention strategies.',
        expectedKeywords: ['circular dependency', 'lock', 'prevention', 'resource ordering', 'timeout', 'detection'],
        explanation: 'Deadlock: circular wait for resources. Prevention: resource ordering, timeout, or deadlock detection/recovery.'
    },
    {
        id: 215,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'What is a view in databases?',
        options: ['Virtual table based on query result', 'Physical table copy', 'Database table', 'Query cache'],
        correctAnswer: 'Virtual table based on query result',
        explanation: 'View is virtual table created from query result, doesn\'t store data separately.'
    },
    {
        id: 216,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'What are stored procedures and their advantages?',
        expectedKeywords: ['pre-compiled', 'security', 'network traffic', 'reusability', 'encapsulation', 'performance'],
        explanation: 'Stored procedures: pre-compiled SQL, improve security, reduce network traffic, increase reusability.'
    },
    {
        id: 217,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'beginner',
        question: 'What is a trigger?',
        options: ['Automatically executes on specific event', 'Manual action', 'Backup process', 'User permission'],
        correctAnswer: 'Automatically executes on specific event',
        explanation: 'Trigger automatically executes stored procedure when specific event occurs on table.'
    },
    {
        id: 218,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'intermediate',
        question: 'Explain query optimization and execution plans.',
        expectedKeywords: ['query optimizer', 'execution plan', 'index usage', 'join strategy', 'efficiency', 'statistics'],
        explanation: 'Query optimizer creates execution plan using statistics. Execution plan shows how DBMS executes query.'
    },
    {
        id: 219,
        type: 'mcq',
        category: 'DBMS',
        difficulty: 'advanced',
        question: 'What is the CAP theorem?',
        options: ['Consistency, Availability, Partition tolerance', 'Only 2 of 3 achievable', 'Both', 'None achievable'],
        correctAnswer: 'Consistency, Availability, Partition tolerance',
        explanation: 'CAP theorem: distributed systems can\'t guarantee all three. Choose 2: Consistency, Availability, or Partition tolerance.'
    },
    {
        id: 220,
        type: 'normal',
        category: 'DBMS',
        difficulty: 'advanced',
        question: 'What is database sharding and replication?',
        expectedKeywords: ['horizontal partitioning', 'data distribution', 'replica', 'backup', 'load balancing', 'fault tolerance'],
        explanation: 'Sharding: horizontally partition data. Replication: copy data across nodes for fault tolerance and load balancing.'
    }
];

module.exports = enhancedQuestions;
