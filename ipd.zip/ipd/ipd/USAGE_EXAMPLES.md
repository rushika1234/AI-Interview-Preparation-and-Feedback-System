# Usage Examples & Walkthrough

## Complete User Walkthrough

### Step 1: Start the System

**Terminal:**
```powershell
cd "c:\Users\Goparapu Sathvika\Desktop\sem-2\ipd\backend"
npm install  # First time only
node server.js
```

**Expected Output:**
```
Questions loaded: 63

========== SERVER STARTED ==========
Server is running on http://localhost:3000
Questions loaded: 63
Is array: true
CORS Enabled for all origins
First question: What is a data structure?
=====================================
```

### Step 2: Open Dashboard

Navigate to:
```
c:\Users\Goparapu Sathvika\Desktop\sem-2\ipd\dashboard.html
```

You should see the login page.

### Step 3: Login

```
Username: student1
Password: password123
Click: [LOGIN]
```

You'll see the dashboard with the Home tab selected showing:
- 4 stat cards (Total Questions, Categories, Interviews, Average Score)
- 4 category cards (Data Structures, Algorithms, DBMS, Python)

---

## Scenario 1: Browse Questions by Category

### User Actions:
1. Click "Questions" tab
2. Select "Data Structures" from dropdown
3. View 20 questions with difficulty badges

### Expected Results:

**Questions displayed:**
```
1. What is a data structure?                    [beginner]
2. Which of the following is a linear data structure?   [beginner]
3. What is the time complexity of accessing an element in an array by index?   [beginner]
...
20. Explain dynamic array and how it handles overflow.   [intermediate]
```

### Browser Console:
- No errors
- CORS headers present
- Questions load in <100ms

---

## Scenario 2: Take a Mock Interview

### User Actions:

```
1. Click "Mock Interview" tab
2. Set: "Number of Questions" = 5
3. Click: [START INTERVIEW]
```

### Interview Flow:

**Question 1 of 5:**
```
"What is a data structure?"

[A way to organize and store data efficiently]
[A programming language]
[A type of algorithm]
[A database management system]

[NEXT] [SKIP]
```

User selects: "A way to organize and store data efficiently"
Clicks: [NEXT]

---

**Question 2 of 5:**
```
"Explain the difference between an array and a linked list."

[Text input field]

[NEXT] [SKIP]
```

User types: "Arrays use contiguous memory for O(1) access time, while linked lists use non-contiguous memory with O(n) access but O(1) insertion/deletion."
Clicks: [NEXT]

---

**Questions 3-5:** Similar flow...

---

### After Submission:

Automatic redirect to Results tab showing comprehensive analysis.

---

## Scenario 3: Analyze Results

### Results Display:

```
┌─────────────────────────────┐
│ Interview Results           │
├─────────────────────────────┤
│ Score: 84/100               │
│ Level: Good                 │
└─────────────────────────────┘

┌─────────────────────────────┐
│ Overall Analysis            │
├─────────────────────────────┤
│ Summary: You demonstrated   │
│ a good grasp of fundamental │
│ concepts with strong        │
│ understanding of data       │
│ structures and their        │
│ applications.              │
│                             │
│ ✓ Strengths:                │
│ • Strong MCQ performance    │
│ • Good understanding of     │
│   arrays and stacks        │
│                             │
│ ✗ Weaknesses:               │
│ • Need more practice on    │
│   linked lists             │
│ • Weak on graph algorithms │
└─────────────────────────────┘

┌─────────────────────────────┐
│ Category Performance        │
├─────────────────────────────┤
│ Data Structures: 84%        │
│ Algorithms: 78%             │
│ DBMS: N/A                   │
└─────────────────────────────┘

┌─────────────────────────────┐
│ Recommendations             │
├─────────────────────────────┤
│ 1. Focus on linked list     │
│    implementation details   │
│ 2. Practice tree traversal  │
│ 3. Study graph algorithms   │
│    on GeeksforGeeks or     │
│    LeetCode                 │
└─────────────────────────────┘

┌─────────────────────────────┐
│ Detailed Feedback           │
├─────────────────────────────┤
│ Q1: What is a data struct?  │
│ ✓ CORRECT (100%)            │
│ Your: "A way to organize..." │
│ Expl: A data structure is.. │
│                             │
│ Q2: Array vs Linked List    │
│ ◐ PARTIAL (70%)             │
│ Your: "Arrays contiguous..."│
│ Score: 70%                  │
│ Missed: insertion, deletion │
│ Expl: Arrays provide O(1).. │
│                             │
│ Q3: Time complexity array   │
│ ✓ CORRECT (100%)            │
│                             │
│ Q4: Stack principle         │
│ ✗ INCORRECT (0%)            │
│ Your: "FIFO"                │
│ Corr: "LIFO"                │
│ Expl: Stack is LIFO where.. │
│                             │
│ Q5: MCQ - different concept │
│ ✓ CORRECT (100%)            │
└─────────────────────────────┘
```

---

## Scenario 4: API Testing (Using Code)

### Test 1: Get All Questions

**JavaScript Code:**
```javascript
fetch('http://localhost:3000/questions/all')
  .then(r => r.json())
  .then(data => {
    console.log('Total Questions:', data.count);  // 63
    console.log('First Question:', data.questions[0].question);
    console.log('Question Types:', 
      data.questions.filter(q => q.type === 'mcq').length, 'MCQs',
      data.questions.filter(q => q.type === 'normal').length, 'Normal'
    );
  });
```

**Response:**
```json
{
  "count": 63,
  "questions": [
    {
      "id": 1,
      "type": "mcq",
      "category": "Data Structures",
      "difficulty": "beginner",
      "question": "What is a data structure?",
      "options": [...],
      "correctAnswer": "A way to organize and store data efficiently",
      "explanation": "..."
    },
    ...
  ]
}
```

---

### Test 2: Get Categories

**JavaScript Code:**
```javascript
fetch('http://localhost:3000/categories')
  .then(r => r.json())
  .then(data => {
    console.log('Categories:', data.categories);
    // Output: ["Data Structures", "Algorithms", "DBMS", "Python"]
  });
```

---

### Test 3: Get Random Questions

**JavaScript Code:**
```javascript
fetch('http://localhost:3000/questions/random/3')
  .then(r => r.json())
  .then(data => {
    console.log('Random Questions:', data.questions.length);
    data.questions.forEach((q, i) => {
      console.log(`${i+1}. ${q.question} (${q.category})`);
    });
  });
```

**Possible Output:**
```
3 random questions:
1. What is an algorithm? (Algorithms)
2. Explain the concept of tree and its terminologies. (Data Structures)
3. What is normalization in databases? (DBMS)
```

---

### Test 4: Submit Interview and Get Feedback

**JavaScript Code:**
```javascript
const responses = [
  {
    questionId: 1,
    answer: "A way to organize and store data efficiently",
    type: "mcq"
  },
  {
    questionId: 11,
    answer: "Arrays store data in contiguous memory blocks",
    type: "normal"
  },
  {
    questionId: 4,
    answer: "LIFO - Last In First Out",
    type: "mcq"
  },
  {
    questionId: 101,
    answer: "An algorithm is a step-by-step procedure to solve a problem",
    type: "mcq"
  },
  {
    questionId: 111,
    answer: "Time complexity describes runtime growth with input size using Big O notation",
    type: "normal"
  }
];

fetch('http://localhost:3000/feedback', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    username: 'student1',
    responses: responses
  })
})
.then(r => r.json())
.then(feedback => {
  console.log('Score:', feedback.summary.overallScore);
  console.log('Level:', feedback.summary.performanceLevel);
  console.log('Strengths:', feedback.overallAnalysis.strengths);
  console.log('Weaknesses:', feedback.overallAnalysis.weaknesses);
  console.log('Recommendations:', feedback.recommendations);
});
```

**Response Structure:**
```json
{
  "summary": {
    "totalQuestions": 5,
    "overallScore": 88,
    "performanceLevel": "Good",
    "timestamp": "2024-01-15T10:30:00Z"
  },
  "categoryWiseAnalysis": [
    {
      "category": "Data Structures",
      "score": 90,
      "totalQuestions": 2
    },
    {
      "category": "Algorithms",
      "score": 85,
      "totalQuestions": 2
    }
  ],
  "overallAnalysis": {
    "strengths": [
      "Strong understanding of MCQ questions",
      "Good grasp of basic data structures",
      "Solid knowledge of algorithm fundamentals"
    ],
    "weaknesses": [
      "Could improve explanation depth for normal questions",
      "Minor gaps in keyword coverage"
    ],
    "summary": "You performed well overall with a Good rating..."
  },
  "recommendations": [
    "Continue practicing MCQ questions for quick recall",
    "Work on detailed explanations for conceptual questions",
    "Study advanced topics to improve from Good to Excellent"
  ],
  "detailedFeedback": [
    {
      "question": "What is a data structure?",
      "type": "mcq",
      "yourAnswer": "A way to organize and store data efficiently",
      "isCorrect": true,
      "correctAnswer": "A way to organize and store data efficiently",
      "explanation": "Correct! Data structures...",
      "score": 100
    },
    {
      "question": "Explain the difference between an array and a linked list.",
      "type": "normal",
      "yourAnswer": "Arrays store data in contiguous memory blocks",
      "score": 80,
      "explanation": "Good answer! You identified the key difference...",
      "matchedKeywords": ["array", "contiguous", "memory"],
      "missingKeywords": ["insertion", "deletion"]
    }
    // ... more feedback items
  ]
}
```

---

## Example Analysis Interpretations

### Scenario: Student gets 88% - Good Rating

**What it means:**
- ✅ Solid understanding of fundamentals
- ✅ Good MCQ performance
- 🔄 Room for improvement on depth
- 📈 Can reach Excellent with focused study

**Recommended next steps:**
1. Focus on areas marked as "weaknesses"
2. Practice normal Q&A to improve explanations
3. Study additional examples in weak categories
4. Retake interview in 1-2 weeks

---

### Scenario: Student gets 45% - Average Rating

**What it means:**
- ⚠️ Basic understanding only
- ❌ Significant knowledge gaps
- 📚 Needs substantial study
- 🎯 Focus on fundamentals first

**Recommended next steps:**
1. Start with beginner questions only
2. Study each concept thoroughly
3. Review explanations for all incorrect answers
4. Practice similar questions from textbooks
5. Build confidence with basics before advanced topics

---

### Scenario: Student gets 95% - Excellent Rating

**What it means:**
- ✅ Outstanding knowledge
- ✅ Ready for interviews
- ✅ Can explain clearly
- 🚀 Interview-ready candidate

**Recommended next steps:**
1. Move to real interview practice
2. Try company-specific interview questions
3. Focus on system design (if applying for senior roles)
4. Practice behavioral questions
5. Prepare for live coding assessments

---

## Performance Tracking (Manual)

### Interview #1
```
Date: Jan 15, 2024
Score: 75%
Level: Fair
Category Strengths: Data Structures (80%)
Category Weaknesses: Algorithms (65%)
```

### Interview #2
```
Date: Jan 17, 2024
Score: 82%
Level: Good
Category Strengths: Data Structures (88%), Algorithms (78%)
Category Weaknesses: DBMS (70%)
```

### Interview #3
```
Date: Jan 19, 2024
Score: 88%
Level: Good
Category Strengths: Data Structures (90%), Algorithms (85%)
Category Weaknesses: DBMS (78%)
```

**Trend:** ✅ Improving (75% → 82% → 88%)

---

## Error Handling Examples

### Scenario 1: Server Not Running
```
Error: fetch failed
Message: Failed to fetch resource
Solution: Start server with: node server.js
```

### Scenario 2: Invalid Category Selection
```
Response: (empty list)
Cause: Category doesn't exist
Solution: Select from available categories
```

### Scenario 3: Incomplete Interview Submission
```
Result: Feedback shows 0% for skipped questions
Cause: No answer provided
Note: Skipped questions count as 0% score
```

---

This walkthrough covers all major use cases and demonstrates the full capability of the AI Interview Preparation and Feedback System!
