# Voice interview integration

This folder contains a minimal frontend recorder and a backend upload endpoint to add voice-based interviews.

Structure
- `frontend/index.html` — simple recorder UI that POSTs recorded audio to the backend.
- `backend/server.js` — Express server with `/upload` endpoint. If `OPENAI_API_KEY` is set, it will call OpenAI `audio/transcriptions` and `chat/completions` to transcribe and evaluate.

Quick start (backend)

1. Open a terminal in `voice/backend`.
2. Install dependencies:

```bash
npm install
```

3. (Optional) Create a `.env` file with your OpenAI key:

```
OPENAI_API_KEY=sk-...
PORT=3001
```

4. Start server:

```bash
npm start
```

Quick start (frontend)

1. Open `voice/frontend/index.html` in a browser. For local development, serve it from a static server (e.g., `npx serve .` or via your existing web app).
2. Ensure the frontend posts to `http://localhost:3001/upload` (the `index.html` uses `/voice/backend/upload` by default if hosted under a proxy; you can change the fetch URL to `http://localhost:3001/upload`).

Notes
- This is non-destructive: it adds new files and does not modify your existing code.
- For production, persist audio to S3 and transcripts/scores to your DB. Add authentication, consent UI and data retention policies.
