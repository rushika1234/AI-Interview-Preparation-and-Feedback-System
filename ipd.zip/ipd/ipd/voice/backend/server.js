require('dotenv').config();
const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const fetch = require('node-fetch');
const FormData = require('form-data');

const upload = multer({ dest: path.join(__dirname, 'uploads/') });
const app = express();
app.use(cors());

async function transcribeWithOpenAI(filePath){
  const key = process.env.OPENAI_API_KEY;
  if(!key) return null;
  const form = new FormData();
  form.append('file', fs.createReadStream(filePath));
  form.append('model', 'whisper-1');
  const resp = await fetch('https://api.openai.com/v1/audio/transcriptions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}` },
    body: form
  });
  if(!resp.ok) throw new Error('OpenAI STT failed: ' + await resp.text());
  const j = await resp.json();
  return j.text || null;
}

async function evaluateWithOpenAI(transcript, expected){
  const key = process.env.OPENAI_API_KEY;
  if(!key) return null;
  const prompt = `You are an interviewer grader. Student response: """${transcript}"""\nExpected answer: """${expected}"""\nRespond with JSON: {"score":<0-10> , "speechText":"short spoken feedback", "bullets":[...]} `;
  const body = {
    model: 'gpt-3.5-turbo',
    messages: [{ role: 'user', content: prompt }],
    max_tokens: 300,
    temperature: 0.2
  };
  const resp = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type':'application/json', Authorization: `Bearer ${key}` },
    body: JSON.stringify(body)
  });
  if(!resp.ok) throw new Error('OpenAI eval failed: ' + await resp.text());
  const j = await resp.json();
  const text = j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content;
  try{ return JSON.parse(text); }catch(e){ return { raw: text }; }
}

app.post('/upload', upload.single('audio'), async (req, res) => {
  if(!req.file) return res.status(400).json({ error: 'missing audio' });
  const tmpPath = req.file.path;
  try{
    let transcript = null;
    try{
      transcript = await transcribeWithOpenAI(tmpPath);
    }catch(err){
      console.warn('STT error', err.message);
    }
    if(!transcript) transcript = req.body.transcript || 'No transcript captured. Please enable microphone speech recognition and try again.';

    // Fetch expected answer from DB by questionId — placeholder
    const questionId = req.body.questionId || 'unknown';
    const expected = req.body.expected || 'Expected answer for ' + questionId;

    let evaluation = null;
    try{
      evaluation = await evaluateWithOpenAI(transcript, expected);
    }catch(err){
      console.warn('Eval error', err.message);
    }
    if(!evaluation) {
      const answerWords = transcript.toLowerCase();
      const expectedWords = expected.toLowerCase().split(/\W+/).filter(word => word.length > 3);
      const matchedWords = [...new Set(expectedWords)].filter(word => answerWords.includes(word));
      const score = expectedWords.length ? Math.min(10, Math.round(matchedWords.length / new Set(expectedWords).size * 10)) : 5;
      evaluation = {
        score,
        bullets: score >= 7
          ? ['Good coverage of the expected concepts.', 'Add a specific example to make the answer stronger.']
          : ['Explain more of the key concepts in the question.', 'Use a clear structure and include a practical example.'],
        speechText: score >= 7 ? 'Good answer. Add a specific example to make it stronger.' : 'Your answer needs more detail. Cover the key concepts and include an example.'
      };
    }

    // Persisting files/metadata is left to integrator (S3/DB). Return result to client.
    res.json({ transcript, evaluation });
  }catch(err){
    console.error(err);
    res.status(500).json({ error: err.message });
  }finally{
    // cleanup
    fs.unlink(req.file.path, ()=>{});
  }
});

const port = process.env.PORT || 3001;
app.listen(port, ()=> console.log(`Voice backend listening on ${port}`));
